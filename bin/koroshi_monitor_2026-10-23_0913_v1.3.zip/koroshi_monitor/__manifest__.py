# -*- coding: utf-8 -*-
{
    'name': 'KOROSHI Monitor zonas',
    'summary': 'Pantalla en directo de como van las agrupaciones de picking por zonas (Z-ddmm-D1..D5, ZX)',
    'description': """
Monitor de las agrupaciones por zonas de KOROSHI.

Menu Inventario > Operaciones > Monitor zonas. Ensena, para la agrupacion elegida
(por defecto la ultima Z-...): unidades leidas y pendientes por zona, OUT hechas /
cogiendose / sin empezar, el cuadro de cada tienda en cada zona y la lista de OUT
por zona con lineales, huecos y horas. Se refresca solo cada minuto.

v1.1: tambien modo "Tiendas <dia>" para cuando se coge una OUT por pedido (sin zonas):
ritmo del equipo, hora prevista de fin, uds por hora y lo que ha tardado cada OUT.

v1.2: en "Tiendas", cajas cerradas por OUT, hace cuanto se cerro la ultima (aviso si una
OUT lleva mas de 20 min sin cerrar caja) y personas cogiendo ahora.

v1.3: "Personas y horas" para cualquier dia (tambien dias anteriores y zonas): personas,
horas-persona, horas de reloj, uds por hora-persona, uds por persona y segundos por prenda,
estimados por las cajas cerradas. Menu en la barra de Inventario, al lado de KOROSHI KPI.

Solo lee: no cambia nada en Odoo.
""",
    'version': '13.0.1.3.0',
    'author': 'NATH',
    'category': 'Warehouse',
    'license': 'LGPL-3',
    'depends': ['web', 'stock', 'stock_picking_batch'],
    'data': [
        'views/assets.xml',
        'views/menu.xml',
    ],
    'installable': True,
    'application': False,
}
