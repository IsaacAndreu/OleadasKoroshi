# -*- coding: utf-8 -*-
# =============================================================================
# KOROSHI KPI: una ficha por dia con lo que se puede sacar de Odoo (uds, SKU, cajas, volumen,
# peso estimado, metros) y lo que se apunta a mano (personas y horas de cada fase). Con eso,
# los segundos por prenda de picking, packing y expedicion, y dentro del picking cuanto es
# andar y cuanto leer. Solo escribe en sus propias tablas.
# =============================================================================
import datetime
import re

import pytz

from odoo import api, fields, models

COMPANY_ID = 8                  # EFFECTIVE LOGISTICS, S.L.
TZ = 'Europe/Madrid'
RE_HUECO = re.compile(r'\bL(\d+) P(\d+)\b')
RE_TIPO = re.compile(r'^\d{4}([A-Z]{2})')

# Plano simplificado de la nave (el mismo de las paginas de recorridos): metros
BASE = (26.0, 30.0)             # salida y vuelta (expediciones / SORTER)
CRUCES = (7.75, 30.0, 44.25)    # pasillos transversales


def _x(lineal):
    return 30 + 2 * (lineal // 2) - 0.5


def _y(pos):
    if pos <= 17:
        if pos == 0:
            return 29.3
        if pos <= 3:
            return 2 + (pos - 0.5) * 1.5
        return 9 + (pos - 3.5) * (20.0 / 14)
    pos = min(pos, 36)
    if pos <= 24:
        return 31 + (pos - 17.5) * (12.0 / 7)
    return 45.5 + (pos - 24.5) * (12.5 / 12)


def metros_ruta(huecos, desde_base=True):
    """Metros de un recorrido: sale de BASE, pasa por los huecos (lineal, posicion) en orden de
    pasillo y posicion, y vuelve. Cambiar de pasillo obliga a ir por el transversal mas corto.
    desde_base=False (zonas: el operario se queda en su zona): solo del primer hueco al ultimo."""
    puntos = sorted(set(huecos), key=lambda h: (h[0] // 2, h[1], h[0]))
    if not puntos:
        return 0.0
    if not desde_base:
        x, y = _x(puntos[0][0]), _y(puntos[0][1])
    else:
        x, y = BASE
        puntos = puntos + [None]
    d = 0.0
    for punto in puntos:
        tx, ty = BASE if punto is None else (_x(punto[0]), _y(punto[1]))
        if abs(tx - x) < 0.01:
            d += abs(ty - y)
        else:
            d += min([abs(y - c) + abs(ty - c) for c in CRUCES]) + abs(tx - x)
        x, y = tx, ty
    return d


def tipo_producto(producto):
    m = RE_TIPO.match(producto.default_code or producto.name or '')
    return m and m.group(1) or ''


class KoroshiKpiPesoTipo(models.Model):
    _name = 'koroshi.kpi.peso.tipo'
    _description = 'KOROSHI KPI - peso y litros por tipo de prenda'
    _order = 'codigo'

    codigo = fields.Char('Tipo', required=True, help='Letras 5 y 6 de la referencia: 2421JA14-... = JA')
    name = fields.Char('Descripción')
    gramos = fields.Float('Peso por prenda (g)', help='Estimado: pesar 10 prendas del tipo y poner la media')
    litros = fields.Float('Litros por prenda', help='Solo se usa si el producto no tiene volumen en Odoo')
    estimado = fields.Boolean('Estimado', default=True, help='Desmarcar cuando se haya pesado de verdad')

    _sql_constraints = [('codigo_uniq', 'unique(codigo)', 'Ya hay una fila con ese tipo.')]


class KoroshiKpiDia(models.Model):
    _name = 'koroshi.kpi.dia'
    _description = 'KOROSHI KPI - dia'
    _order = 'fecha desc'

    fecha = fields.Date('Día', required=True, default=fields.Date.context_today)
    name = fields.Char('Nombre', compute='_compute_name', store=True)
    metodo = fields.Selection([('tradicional', 'Tradicional (1 OUT por pedido)'), ('zonas', 'Zonas'),
                               ('oleada', 'Oleada + U'), ('mixto', 'Mixto')], string='Método')
    tipo_pedido = fields.Char('Tipo de pedido', default='PED. TIENDAS')
    notas = fields.Text('Notas')

    # ---------------- A mano: personas y horas (horas por persona) ----------------
    pick_personas = fields.Integer('Personas picking')
    pick_horas = fields.Float('Horas picking (por persona)')
    pack_personas = fields.Integer('Personas packing')
    pack_horas = fields.Float('Horas packing (por persona)')
    exp_personas = fields.Integer('Personas expedición')
    exp_horas = fields.Float('Horas expedición (por persona)')
    velocidad = fields.Float('Velocidad andando (m/s)', default=1.0,
                             help='Con carro, contando paradas: 1 m/s = 3,6 km/h')

    # ---------------- De Odoo (boton Recalcular y cada noche) ----------------
    uds = fields.Float('Uds totales', readonly=True)
    lineas = fields.Integer('Líneas', readonly=True)
    skus = fields.Integer('SKU distintos', readonly=True)
    pedidos = fields.Integer('Pedidos', readonly=True)
    outs = fields.Integer('OUT', readonly=True)
    cajas = fields.Integer('Cajas (matrículas)', readonly=True)
    volumen_total = fields.Float('Volumen total (m³)', readonly=True, digits=(16, 3))
    uds_volumen_estimado = fields.Float('Uds con volumen estimado por tipo', readonly=True)
    peso_total = fields.Float('Peso total (kg)', readonly=True, digits=(16, 1))
    metros_total = fields.Float('Metros recorridos', readonly=True, digits=(16, 0))
    recorridos = fields.Integer('Recorridos (OUT/INT con huecos)', readonly=True)
    primera_caja = fields.Datetime('Primera caja', readonly=True)
    ultima_caja = fields.Datetime('Última caja', readonly=True)
    recalculado = fields.Datetime('Recalculado el', readonly=True)

    # ---------------- KPI (se recalculan solos al cambiar lo de arriba) ----------------
    profundidad_sku = fields.Float('Profundidad por SKU (uds/SKU)', compute='_compute_kpi', store=True,
                                   group_operator='avg', digits=(16, 2))
    uds_caja = fields.Float('Uds por caja', compute='_compute_kpi', store=True, group_operator='avg', digits=(16, 1))
    peso_ud = fields.Float('Peso medio por ud (g)', compute='_compute_kpi', store=True, group_operator='avg', digits=(16, 0))
    volumen_ud = fields.Float('Volumen por ud (m³/ud)', compute='_compute_kpi', store=True, group_operator='avg',
                              digits=(16, 5))
    metros_ud = fields.Float('Metros por ud', compute='_compute_kpi', store=True, group_operator='avg', digits=(16, 2))
    hp_picking = fields.Float('Horas-persona picking', compute='_compute_kpi', store=True)
    hp_packing = fields.Float('Horas-persona packing', compute='_compute_kpi', store=True)
    hp_expedicion = fields.Float('Horas-persona expedición', compute='_compute_kpi', store=True)
    hp_total = fields.Float('Horas totales', compute='_compute_kpi', store=True)
    personas_total = fields.Integer('Personas (suma de fases)', compute='_compute_kpi', store=True,
                                    help='Si una persona hace dos fases cuenta dos veces')
    h_andando = fields.Float('Horas andando (picking)', compute='_compute_kpi', store=True)
    h_leyendo = fields.Float('Horas leyendo/cogiendo (picking)', compute='_compute_kpi', store=True)
    s_ud_picking = fields.Float('s/ud picking', compute='_compute_kpi', store=True, group_operator='avg', digits=(16, 1))
    s_ud_andando = fields.Float('s/ud andando', compute='_compute_kpi', store=True, group_operator='avg', digits=(16, 1))
    s_ud_leyendo = fields.Float('s/ud leyendo', compute='_compute_kpi', store=True, group_operator='avg', digits=(16, 1))
    s_ud_packing = fields.Float('s/ud packing', compute='_compute_kpi', store=True, group_operator='avg', digits=(16, 1))
    s_ud_expedicion = fields.Float('s/ud expedición', compute='_compute_kpi', store=True, group_operator='avg',
                                   digits=(16, 1))
    s_ud_total = fields.Float('s/ud TOTAL', compute='_compute_kpi', store=True, group_operator='avg', digits=(16, 1))
    uds_hora_persona = fields.Float('Uds por hora-persona', compute='_compute_kpi', store=True, group_operator='avg',
                                    digits=(16, 0))

    _sql_constraints = [('fecha_uniq', 'unique(fecha)', 'Ya hay una ficha para ese día.')]

    @api.depends('fecha')
    def _compute_name(self):
        for r in self:
            r.name = r.fecha and r.fecha.strftime('%d/%m/%Y') or ''

    @api.depends('uds', 'skus', 'cajas', 'peso_total', 'volumen_total', 'metros_total', 'velocidad',
                 'pick_personas', 'pick_horas', 'pack_personas', 'pack_horas', 'exp_personas', 'exp_horas')
    def _compute_kpi(self):
        for r in self:
            u = r.uds or 0.0
            r.profundidad_sku = r.skus and u / r.skus or 0.0
            r.uds_caja = r.cajas and u / r.cajas or 0.0
            r.peso_ud = u and r.peso_total * 1000.0 / u or 0.0
            r.volumen_ud = u and r.volumen_total / u or 0.0
            r.metros_ud = u and r.metros_total / u or 0.0
            r.hp_picking = r.pick_personas * r.pick_horas
            r.hp_packing = r.pack_personas * r.pack_horas
            r.hp_expedicion = r.exp_personas * r.exp_horas
            r.hp_total = r.hp_picking + r.hp_packing + r.hp_expedicion
            r.personas_total = r.pick_personas + r.pack_personas + r.exp_personas
            andando = r.velocidad and r.metros_total / r.velocidad / 3600.0 or 0.0
            r.h_andando = r.hp_picking and min(andando, r.hp_picking) or andando
            r.h_leyendo = max(r.hp_picking - r.h_andando, 0.0)
            r.s_ud_picking = u and r.hp_picking * 3600.0 / u or 0.0
            r.s_ud_andando = u and r.h_andando * 3600.0 / u or 0.0
            r.s_ud_leyendo = u and r.h_leyendo * 3600.0 / u or 0.0
            r.s_ud_packing = u and r.hp_packing * 3600.0 / u or 0.0
            r.s_ud_expedicion = u and r.hp_expedicion * 3600.0 / u or 0.0
            r.s_ud_total = r.s_ud_picking + r.s_ud_packing + r.s_ud_expedicion
            r.uds_hora_persona = r.hp_total and u / r.hp_total or 0.0

    # ---------------- Calculo de lo que sale de Odoo ----------------
    def _rango_utc(self):
        tz = pytz.timezone(TZ)
        ini = tz.localize(datetime.datetime.combine(self.fecha, datetime.time.min))
        ini = ini.astimezone(pytz.utc).replace(tzinfo=None)
        return ini, ini + datetime.timedelta(days=1)

    def action_recalcular(self):
        Line = self.env['stock.move.line'].sudo()
        Pick = self.env['stock.picking'].sudo()
        tipos = {}
        defecto = (300.0, 3.0)
        for t in self.env['koroshi.kpi.peso.tipo'].sudo().search([]):
            tipos[t.codigo] = (t.gramos or defecto[0], t.litros or defecto[1])
        sorter = self.env['stock.location'].sudo().search([('barcode', '=', 'SORTER'),
                                                           ('company_id', '=', COMPANY_ID)], limit=1)
        en_sorter = set(sorter and self.env['stock.location'].sudo().search([('id', 'child_of', sorter.id)]).ids or [])
        for r in self:
            ini, fin = r._rango_utc()
            base = [('picking_id.company_id', '=', COMPANY_ID), ('picking_id.picking_type_code', '=', 'outgoing'),
                    ('qty_done', '>', 0)]
            if r.tipo_pedido:
                base.append(('picking_id.sale_id.s_order_type_id.name', '=', r.tipo_pedido))
            # Unidades del dia: las de las cajas cerradas ese dia; sin caja, las de las OUT validadas ese dia
            lineas = Line.search(base + [('result_package_id.create_date', '>=', ini),
                                         ('result_package_id.create_date', '<', fin)])
            lineas |= Line.search(base + [('result_package_id', '=', False), ('picking_id.date_done', '>=', ini),
                                          ('picking_id.date_done', '<', fin)])
            uds = vol = peso = vol_est = 0.0
            productos = set()
            pedidos = set()
            outs = set()
            cajas = set()
            horas = []
            huecos = {}         # picking -> [(lineal, posicion)] para los metros
            for ml in lineas:
                q = ml.qty_done
                p = ml.product_id
                g, l = tipos.get(tipo_producto(p), defecto)
                uds += q
                peso += g * q / 1000.0
                if p.volume > 0:
                    vol += p.volume * q
                else:
                    vol += l / 1000.0 * q
                    vol_est += q
                productos.add(p.id)
                pedidos.add(ml.picking_id.origin or ml.picking_id.name)
                outs.add(ml.picking_id.id)
                if ml.result_package_id:
                    cajas.add(ml.result_package_id.id)
                    horas.append(ml.result_package_id.create_date)
                if ml.location_id.id not in en_sorter:      # las OUT de oleada salen del SORTER: se anda en los INT
                    h = RE_HUECO.search(ml.location_id.complete_name or '')
                    if h:
                        huecos.setdefault(ml.picking_id.id, []).append((int(h.group(1)), int(h.group(2))))
            # Oleada: lo que se anda son los INT al SORTER cogidos ese dia
            if sorter:
                ints = Line.search([('picking_id.company_id', '=', COMPANY_ID),
                                    ('picking_id.picking_type_code', '=', 'internal'),
                                    ('picking_id.location_dest_id', '=', sorter.id),
                                    ('qty_done', '>', 0), ('write_date', '>=', ini), ('write_date', '<', fin)])
                for ml in ints:
                    h = RE_HUECO.search(ml.location_id.complete_name or '')
                    if h:
                        huecos.setdefault(ml.picking_id.id, []).append((int(h.group(1)), int(h.group(2))))
            metros = 0.0
            for pid, lista in huecos.items():
                lote = Pick.browse(pid).batch_id.name or ''
                metros += metros_ruta(lista, desde_base=not lote.startswith('Z-'))
            r.write({
                'uds': uds, 'lineas': len(lineas), 'skus': len(productos), 'pedidos': len(pedidos),
                'outs': len(outs), 'cajas': len(cajas), 'volumen_total': vol, 'uds_volumen_estimado': vol_est,
                'peso_total': peso, 'metros_total': metros, 'recorridos': len(huecos),
                'primera_caja': horas and min(horas) or False, 'ultima_caja': horas and max(horas) or False,
                'recalculado': fields.Datetime.now(),
            })
        return True

    @api.model
    def cron_recalcular(self):
        # Cada noche: crea la ficha de hoy si no esta y recalcula hoy y ayer
        hoy = datetime.datetime.now(pytz.timezone(TZ)).date()
        for d in (hoy - datetime.timedelta(days=1), hoy):
            ficha = self.search([('fecha', '=', d)], limit=1) or self.create({'fecha': d})
            ficha.action_recalcular()
        return True
