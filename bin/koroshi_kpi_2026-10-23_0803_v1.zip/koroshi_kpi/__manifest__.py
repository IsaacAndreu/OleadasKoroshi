# -*- coding: utf-8 -*-
{
    'name': 'KOROSHI KPI',
    'summary': 'KPI diarios del almacen KOROSHI: uds, profundidad por SKU, peso, volumen, metros y segundos por prenda',
    'description': """
KPI diarios del picking de KOROSHI (Effective Logistics).

Una ficha por dia (Inventario > KOROSHI KPI > Dias):
- Calculado de Odoo (boton Recalcular y cada noche): uds, lineas, SKU, profundidad por SKU,
  pedidos, OUT, cajas, volumen total y por ud (volumen del producto o litros del tipo),
  peso total y por ud (tabla de pesos por tipo, estimada), metros recorridos (modelo de la nave)
  y hora de la primera y la ultima caja.
- A mano: personas y horas de picking, packing y expedicion.
- Resultado: segundos por prenda de cada fase y total, tiempo andando y leyendo dentro del
  picking (metros / velocidad), horas totales y personas.

Solo escribe en sus propias tablas: no cambia albaranes, stock ni productos.
""",
    'version': '13.0.1.0.0',
    'author': 'NATH',
    'category': 'Warehouse',
    'license': 'LGPL-3',
    'depends': ['stock', 'sale_stock'],
    'data': [
        'security/ir.model.access.csv',
        'data/peso_tipo.xml',
        'data/cron.xml',
        'views/kpi_views.xml',
    ],
    'installable': True,
    'application': False,
}
