# -*- coding: utf-8 -*-
# =============================================================================
# KOROSHI Operarios - pantalla de lecturas para la PDA.
#
# GET  /koroshi/operarios                 pagina (usuario con sesion, p. ej. "Almacen Nath")
# JSON /koroshi/operarios/leer            {codigo, employee_id}  -> tarjeta o pedido
# JSON /koroshi/operarios/dejar           {employee_id}          -> "Dejar aqui"
# JSON /koroshi/operarios/estado          {}                     -> tareas abiertas de hoy
#
# La tarjeta se busca en todas las empresas (sirve en los dos almacenes). Solo escribe en
# koroshi.operario.tarea (con sudo, porque el usuario de la PDA no tiene permisos sobre ella).
# =============================================================================
import pytz

from odoo import fields, http
from odoo.exceptions import UserError
from odoo.http import request

from ..models.tarea import ZONA_HORARIA


def _hora(dt):
    if not dt:
        return ''
    return pytz.utc.localize(dt).astimezone(pytz.timezone(ZONA_HORARIA)).strftime('%H:%M')


def _tarea_json(t):
    if not t:
        return False
    ref = t.batch_id.name if t.tipo == 'agrupacion' else t.picking_id.name
    tienda = '' if t.tipo == 'agrupacion' else (t.picking_id.partner_id.name or '')
    return {
        'id': t.id,
        'operario': t.employee_id.name,
        'ref': ref or t.referencia or '',
        'tipo': t.tipo,
        'tienda': tienda,
        'inicio': _hora(t.inicio),
        'estado': t.estado,
        'uds_total': t.uds_total,
    }


class KoroshiOperarios(http.Controller):

    def _empleado(self, employee_id):
        emp = request.env['hr.employee'].sudo().browse(int(employee_id or 0)).exists()
        if not emp:
            raise UserError('Lee primero tu tarjeta')
        return emp

    @http.route('/koroshi/operarios', type='http', auth='user')
    def pagina(self, **kw):
        return request.render('koroshi_operarios.pagina_lecturas', {})

    @http.route('/koroshi/operarios/leer', type='json', auth='user')
    def leer(self, codigo='', employee_id=False, **kw):
        codigo = (codigo or '').strip()
        if not codigo:
            return {'ok': False, 'msg': 'Codigo vacio'}
        Emp = request.env['hr.employee'].sudo().with_context(active_test=True)
        emp = Emp.search([('barcode', '=', codigo)], limit=1)
        Tarea = request.env['koroshi.operario.tarea'].sudo()
        if emp:
            return {'ok': True, 'que': 'tarjeta', 'employee_id': emp.id, 'operario': emp.name,
                    'abierta': _tarea_json(Tarea.abierta_de(emp))}
        try:
            emp = self._empleado(employee_id)
            tarea, mensaje = Tarea.empezar(emp, codigo)
        except UserError as e:
            return {'ok': False, 'msg': e.name if hasattr(e, 'name') else str(e)}
        return {'ok': True, 'que': 'empezada', 'msg': mensaje, 'tarea': _tarea_json(tarea)}

    @http.route('/koroshi/operarios/dejar', type='json', auth='user')
    def dejar(self, employee_id=False, **kw):
        Tarea = request.env['koroshi.operario.tarea'].sudo()
        try:
            emp = self._empleado(employee_id)
            tarea = Tarea.dejar(emp)
        except UserError as e:
            return {'ok': False, 'msg': e.name if hasattr(e, 'name') else str(e)}
        return {'ok': True, 'que': 'dejada', 'tarea': _tarea_json(tarea), 'uds': tarea.uds,
                'minutos': round(tarea.minutos)}

    @http.route('/koroshi/operarios/estado', type='json', auth='user')
    def estado(self, **kw):
        Tarea = request.env['koroshi.operario.tarea'].sudo()
        abiertas = Tarea.search([('estado', '=', 'curso')], order='inicio asc', limit=200)
        return {'ok': True, 'ahora': _hora(fields.Datetime.now()),
                'abiertas': [_tarea_json(t) for t in abiertas]}
