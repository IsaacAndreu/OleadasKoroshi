# -*- coding: utf-8 -*-
{
    'name': 'KOROSHI Operarios',
    'summary': 'Quien coge cada pedido: el operario lee su tarjeta y el pedido al empezar; tiempo y uds por persona',
    'description': """
Productividad por operario sin usuarios de Odoo (KOROSHI, Effective Logistics).

- Cada operario es un empleado (hr.employee) con un codigo en "ID de credencial" (OP0001...).
  No es un usuario de Odoo. Asistente para crear muchos de golpe y tarjetas con "Imprimir Identificacion".
- Pantalla de lecturas para la PDA (/koroshi/operarios, menu Inventario > KOROSHI Operarios > Lecturas):
  tarjeta + pedido = empieza; tarjeta + "Dejar aqui" = lo deja a medias. Si empieza otro pedido, el
  anterior se cierra solo como dejado.
- Pedido = codigo de la OUT (el que sale en "Transferir agrupacion" y en el albaran) o nombre de la
  agrupacion. Si la OUT es de una agrupacion de zonas (Z-...), la tarea es de toda la agrupacion.
- Cada 5 minutos se cierran solas las tareas cuyo pedido o agrupacion ya esta validado. A medianoche lo
  que sigue abierto queda "Sin cerrar".
- Uds de cada tarea = uds leidas del pedido al cerrar - uds leidas al empezar.
- Informes: tareas por operario y dia (lista, tabla dinamica, grafico) y OUT validadas hoy sin operario.

Solo escribe en sus propias tablas y en hr.employee (crear operarios). No anade campos a albaranes,
movimientos, agrupaciones ni tipos de operacion, y no cambia la app de codigo de barras.

v1.0 (09/11/2026): primera version.
""",
    'version': '13.0.1.0.0',
    'author': 'NATH',
    'category': 'Warehouse',
    'license': 'LGPL-3',
    'depends': ['web', 'hr', 'stock', 'stock_picking_batch'],
    'data': [
        'security/ir.model.access.csv',
        'data/categoria.xml',
        'data/cron.xml',
        'views/tarea_views.xml',
        'views/wizard_views.xml',
        'views/pagina.xml',
        'views/menu.xml',
    ],
    'installable': True,
    'application': False,
}
