/* KOROSHI Operarios - pantalla de lecturas.
 * La PDA lee como un teclado y acaba con Enter. Tarjeta -> queda elegido el operario VENTANA segundos;
 * pedido -> empieza; boton "Dejar aqui" -> deja el pedido del operario elegido.
 */
(function () {
    'use strict';
    var VENTANA = 90;          // segundos que vale la tarjeta
    var operario = null;       // {id, nombre, hasta}
    var $ = function (id) { return document.getElementById(id); };

    function rpc(url, params) {
        return fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({jsonrpc: '2.0', method: 'call', params: params || {}})
        }).then(function (r) { return r.json(); }).then(function (j) {
            if (j.error) {
                var m = (j.error.data && j.error.data.message) || j.error.message || 'Error';
                return {ok: false, msg: m};
            }
            return j.result;
        }).catch(function () { return {ok: false, msg: 'Sin conexion con Odoo'}; });
    }

    function aviso(texto, clase) {
        var a = $('aviso');
        a.textContent = texto || '';
        a.className = 'caja ' + (texto ? clase : '');
    }

    function pitido(bien) {
        try {
            var ctx = new (window.AudioContext || window.webkitAudioContext)();
            var o = ctx.createOscillator();
            o.frequency.value = bien ? 880 : 220;
            o.connect(ctx.destination);
            o.start();
            setTimeout(function () { o.stop(); ctx.close(); }, bien ? 120 : 400);
        } catch (e) { /* sin sonido */ }
    }

    function pintarOperario(abierta) {
        var q = $('quien');
        if (!operario) {
            q.className = 'caja vacio';
            q.textContent = 'Lee tu tarjeta';
            $('dejar').disabled = true;
            return;
        }
        q.className = 'caja';
        q.textContent = operario.nombre;
        var sub = document.createElement('span');
        sub.className = 'sub';
        sub.textContent = abierta ? ('Tienes empezado ' + abierta.ref + ' desde las ' + abierta.inicio +
            '. Lee otro pedido o pulsa Dejar aquí.') : 'Lee el pedido que vas a coger';
        q.appendChild(sub);
        $('dejar').disabled = !abierta;
    }

    function olvidarOperario() {
        operario = null;
        pintarOperario(null);
    }

    function pintarAbiertas() {
        rpc('/koroshi/operarios/estado').then(function (r) {
            if (!r || !r.ok) { return; }
            $('reloj').textContent = r.ahora;
            var cont = $('abiertas');
            cont.innerHTML = '';
            r.abiertas.forEach(function (t) {
                var f = document.createElement('div');
                f.className = 'fila';
                var a = document.createElement('span');
                var b = document.createElement('b');
                b.textContent = t.operario;
                a.appendChild(b);
                a.appendChild(document.createTextNode(' · ' + t.ref + (t.tienda ? ' · ' + t.tienda : '')));
                var h = document.createElement('span');
                h.textContent = t.inicio;
                f.appendChild(a);
                f.appendChild(h);
                cont.appendChild(f);
            });
            if (!r.abiertas.length) { cont.textContent = 'Nadie'; }
        });
    }

    function leer(codigo) {
        if (operario && Date.now() > operario.hasta) { olvidarOperario(); }
        rpc('/koroshi/operarios/leer', {codigo: codigo, employee_id: operario ? operario.id : false}).then(function (r) {
            if (!r || !r.ok) {
                aviso((r && r.msg) || 'Error', 'mal');
                pitido(false);
                return;
            }
            if (r.que === 'tarjeta') {
                operario = {id: r.employee_id, nombre: r.operario, hasta: Date.now() + VENTANA * 1000};
                pintarOperario(r.abierta);
                aviso('', '');
                pitido(true);
                return;
            }
            if (r.que === 'empezada') {
                aviso((r.msg ? r.msg.trim() + ' · ' : '') + 'Empezado ' + r.tarea.ref + ' a las ' + r.tarea.inicio + ' · ' +
                      Math.round(r.tarea.uds_total) + ' uds', 'ok');
                pitido(true);
                olvidarOperario();
                pintarAbiertas();
            }
        });
    }

    function dejar() {
        if (!operario) { return; }
        rpc('/koroshi/operarios/dejar', {employee_id: operario.id}).then(function (r) {
            if (!r || !r.ok) {
                aviso((r && r.msg) || 'Error', 'mal');
                pitido(false);
                return;
            }
            aviso(operario.nombre + ' deja ' + r.tarea.ref + ' (' + Math.round(r.uds) + ' uds en ' + r.minutos + ' min)', 'info');
            pitido(true);
            olvidarOperario();
            pintarAbiertas();
        });
    }

    var input = $('codigo');
    input.addEventListener('keydown', function (ev) {
        if (ev.key === 'Enter' || ev.keyCode === 13) {
            ev.preventDefault();
            var c = input.value.trim();
            input.value = '';
            if (c) { leer(c); }
        }
    });
    $('dejar').addEventListener('click', function () { dejar(); input.focus(); });
    // el campo siempre listo para leer
    document.addEventListener('click', function (ev) { if (ev.target.id !== 'dejar') { input.focus(); } });
    input.addEventListener('blur', function () { setTimeout(function () { input.focus(); }, 200); });
    setInterval(function () {
        if (operario && Date.now() > operario.hasta) { olvidarOperario(); }
    }, 5000);
    setInterval(pintarAbiertas, 60000);
    input.focus();
    pintarAbiertas();
})();
