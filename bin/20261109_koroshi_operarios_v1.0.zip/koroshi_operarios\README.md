# KOROSHI Operarios (v1.0, 09/11/2026)

Saber quién coge cada pedido sin crear usuarios de Odoo. Cada operario es un **empleado** con una tarjeta.
Al empezar un pedido, lee su tarjeta y el pedido en la PDA. El tiempo se cierra solo cuando se valida el pedido.

## Cómo se usa

1. **Crear los operarios:** menú *Inventario > KOROSHI Operarios > Crear operarios*. Se escribe un nombre por línea.
   - Cada uno se crea como empleado de EFFEC con el código `OP0001`, `OP0002`... en *ID de credencial* y la etiqueta *Operario KOROSHI*.
   - No se crea ningún usuario.
2. **Tarjetas:** *KOROSHI Operarios > Operarios*, seleccionarlos y luego *Imprimir > Imprimir Identificación*.
3. **En la PDA:** abrir *KOROSHI Operarios > Lecturas (PDA)* (`/koroshi/operarios`) con el usuario de siempre.
   - **Empezar:** leer la tarjeta y después el pedido.
     - El pedido es el código de la OUT, el que sale en *Transferir agrupación* y en el albarán.
     - Si la OUT es de una agrupación de zonas (`Z-...`), la tarea es de toda la agrupación.
     - También vale el nombre de la agrupación.
   - **Dejarlo a medias:** leer la tarjeta y pulsar **Dejar aquí**.
   - Si el operario empieza otro pedido, el anterior se cierra solo como *dejado*.
   - La tarjeta vale 90 s para leer el pedido.
4. **Cierre automático (cron cada 5 min):**
   - Si el pedido o la agrupación está validado, la tarea pasa a *acabada*, con la hora de validación.
   - Lo que sigue abierto de días anteriores pasa a *sin cerrar*, con la hora de la última lectura.
5. **Informes:**
   - *Tareas*: hoy, por defecto.
   - *Productividad*: tabla dinámica de operario por día, con uds y minutos, de los últimos 7 días.
   - *OUT validadas hoy sin operario*: muestra quién no usa la tarjeta.

## Qué cuenta

- **Uds de una tarea** = uds leídas (`qty_done`) del pedido o la agrupación al cerrar, menos las leídas al empezar.
  - Si un pedido lo deja uno y lo sigue otro, cada uno tiene las suyas.
  - Si dos personas cogen la misma agrupación a la vez, las uds del rato se cuentan en las dos tareas.
- **Minutos** = desde la lectura del pedido hasta la validación, *Dejar aquí* u otro pedido.
- **Uds/hora** = uds × 60 / minutos.

## Seguridad

- Solo escribe en `koroshi.operario.tarea` y, desde el asistente, crea `hr.employee`.
- **No añade campos** a `stock.picking`, `stock.move(.line)`, `stock.picking.batch` ni `stock.picking.type`.
  Ojo: el 03/11 un campo en `stock.picking.type` tumbó la PDA.
- No toca la app de código de barras.
- La pantalla usa rutas propias (`/koroshi/operarios/*`) y escribe con `sudo` solo en su tabla.
  La tarjeta se busca en todas las empresas.
- Los empleados sin usuario no son usuarios de Odoo. Hay que confirmar con el partner si el contrato
  cuenta los empleados de RRHH como *Light Users*.
- Hay que informar a la plantilla y a sus representantes antes de usarlo para medir el rendimiento.

## Ficheros

```
models/tarea.py              koroshi.operario.tarea + cron + informe sin operario
wizard/crear_operarios.py    crear operarios de golpe
controllers/main.py          /koroshi/operarios (pagina) y /leer, /dejar, /estado (json)
views/pagina.xml             pagina de lecturas (QWeb, sin menus de Odoo)
static/src/js|css            pantalla de la PDA
views/tarea_views.xml        lista, ficha, pivot, grafico, filtros, acciones
data/cron.xml                cron de cierre (5 min)
data/categoria.xml           etiqueta "Operario KOROSHI"
```
