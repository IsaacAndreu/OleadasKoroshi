# -*- coding: utf-8 -*-
from odoo import fields, models


class KoroshiContenedorMovimiento(models.Model):
    _name = 'koroshi.contenedor.movimiento'
    _description = 'KOROSHI: movimiento de contenedor entre ubicaciones'
    _order = 'id desc'

    contenedor = fields.Char('Contenedor', required=True, index=True)
    origen_id = fields.Many2one('stock.location', 'Origen (hueco)', ondelete='set null')
    destino_id = fields.Many2one('stock.location', 'Destino (hueco)', ondelete='set null')
    origen = fields.Char('Origen')
    destino = fields.Char('Destino')
    uds = fields.Float('Uds', digits=(16, 2))
    reservadas = fields.Float('Reservadas', digits=(16, 2))
    lineas = fields.Integer('Referencias')
    user_id = fields.Many2one('res.users', 'Quién', default=lambda s: s.env.uid)
