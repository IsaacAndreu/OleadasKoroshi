odoo.define('koroshi_contenedores.Pantalla', function (require) {
'use strict';
/* KOROSHI Contenedores v1.0.0 - mover contenedores KO_/TT_ de un hueco a otro.
 * Escanear 1 o más contenedores (se ven sus prendas y reservas) y después la ubicación de destino: se mueven al
 * momento. Todo dentro de .o_koroshi_contenedores. */
var AbstractAction = require('web.AbstractAction');
var core = require('web.core');
var REPETIDA_MS = 700;

function _e(t) { return _.escape(t == null ? '' : String(t)); }
function _n(x) { return (Math.round((x || 0) * 100) / 100).toString().replace('.', ','); }

var Pantalla = AbstractAction.extend({
    contentTemplate: 'koroshi_contenedores.Pantalla',
    events: {
        'keydown .o_kc_codigo': '_onKeydown',
        'click .o_kc_quitar': '_onQuitar',
        'click .o_kc_vaciar': '_onVaciar',
    },

    init: function () {
        this._super.apply(this, arguments);
        this.conts = [];
        this.ocupado = false;
        this.ultima = {codigo: '', t: 0};
    },

    start: function () {
        var self = this;
        core.bus.on('barcode_scanned', this, this._onBarcodeScanned);
        return this._super.apply(this, arguments).then(function () {
            self._pintar();
            self._foco();
        });
    },

    destroy: function () {
        core.bus.off('barcode_scanned', this, this._onBarcodeScanned);
        this._super.apply(this, arguments);
    },

    _foco: function () {
        var $c = this.$('.o_kc_codigo');
        if ($c.length && document.activeElement !== $c[0]) { $c.focus(); }
    },

    _onKeydown: function (ev) {
        if (ev.which === 13) {
            ev.preventDefault();
            var codigo = (ev.currentTarget.value || '').trim();
            ev.currentTarget.value = '';
            this._leer(codigo);
        }
    },

    _onBarcodeScanned: function (codigo) { this._leer(codigo); },

    _aviso: function (tipo, msg) {
        this.$('.o_kc_aviso').removeClass('o_kc_ok o_kc_mal').addClass(tipo ? 'o_kc_' + tipo : '').text(msg || '');
    },

    _leer: function (codigo) {
        var self = this;
        codigo = (codigo || '').trim();
        if (!codigo || this.ocupado) { return; }
        var t = Date.now();
        if (codigo === this.ultima.codigo && t - this.ultima.t < REPETIDA_MS) { return; }
        this.ultima = {codigo: codigo, t: t};
        this.ocupado = true;
        return this._rpc({route: '/koroshi/contenedores/leer', params: {codigo: codigo}}).then(function (r) {
            if (!r || !r.ok) {
                self.ocupado = false;
                self._aviso('mal', (r && r.msg) || 'No se ha podido leer.');
                return;
            }
            if (r.tipo === 'contenedor') {
                self.ocupado = false;
                var c = r.contenedor;
                if (!_.findWhere(self.conts, {id: c.id})) { self.conts.push(c); }
                self._aviso('', '');
                self._pintar();
                return;
            }
            if (!self.conts.length) {
                self.ocupado = false;
                self._aviso('mal', 'Primero escanea el contenedor (KO_…) que quieres mover.');
                return;
            }
            return self._rpc({route: '/koroshi/contenedores/mover', params: {
                contenedor_ids: _.pluck(self.conts, 'id'), destino_id: r.ubicacion.id}}).then(function (m) {
                self.ocupado = false;
                if (!m || !m.ok) {
                    self._aviso('mal', (m && m.msg) || 'No se ha podido mover.');
                    return;
                }
                self.conts = [];
                self._pintar();
                self._aviso('ok', '✓ Movido: ' + m.msg);
            }, function () { self.ocupado = false; self._aviso('mal', 'Sin conexión con Odoo.'); });
        }, function () {
            self.ocupado = false;
            self._aviso('mal', 'Sin conexión con Odoo. Vuelve a probar.');
        });
    },

    _onQuitar: function (ev) {
        var id = parseInt($(ev.currentTarget).data('id'), 10);
        this.conts = _.reject(this.conts, function (c) { return c.id === id; });
        this._pintar();
        this._foco();
    },

    _onVaciar: function () {
        this.conts = [];
        this._aviso('', '');
        this._pintar();
        this._foco();
    },

    _pintar: function () {
        this.$('.o_kc_paso').text(this.conts.length
            ? 'Ahora escanea la ubicación de destino (o más contenedores).'
            : '1. Escanea el contenedor (KO_…)');
        var html = this.conts.map(function (c) {
            var filas = c.lineas.map(function (l) {
                return '<tr><td>' + _e(l.producto) + '</td><td class="o_kc_n">' + _n(l.uds) +
                    (l.reservadas ? ' (res. ' + _n(l.reservadas) + ')' : '') + '</td></tr>';
            }).join('');
            if (c.mas) { filas += '<tr><td colspan="2">… y ' + c.mas + ' referencias más</td></tr>'; }
            var cuerpo = c.n_lineas
                ? '<div>' + c.n_lineas + ' ref. · ' + _n(c.uds) + ' uds' +
                    (c.reservadas ? ' · ' + _n(c.reservadas) + ' reservadas (se conservan)' : '') +
                    '</div><table>' + filas + '</table>'
                : '<div class="o_kc_vacio">Sin prendas en el sistema</div>';
            return '<div class="o_kc_card"><button type="button" class="o_kc_quitar" data-id="' + c.id +
                '">Quitar</button><h3>' + _e(c.nombre) + '</h3><div class="o_kc_hueco">Ahora en: ' +
                _e(c.hueco) + '</div>' + cuerpo + '</div>';
        }).join('');
        this.$('.o_kc_lista').html(html);
    },
});

core.action_registry.add('koroshi_contenedores_pantalla', Pantalla);
return Pantalla;
});
