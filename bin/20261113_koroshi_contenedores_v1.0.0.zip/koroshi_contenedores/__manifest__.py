# -*- coding: utf-8 -*-
{
    'name': 'KOROSHI Contenedores (mover de ubicación)',
    'summary': 'Escanear contenedores KO_/TT_ y la ubicación de destino: se mueven con sus prendas y reservas.',
    'description': """
Mover contenedores (sububicaciones KO_... / TT_... de un hueco) de un hueco a otro al compactar.

- Pantalla para la PDA o el portátil (Inventario > KOROSHI Operarios > Contenedores, y app «Contenedores»).
- Se escanea uno o varios contenedores (KO_240826_1327): salen su ubicación actual y sus prendas (uds y reservadas).
  Se escanea la ubicación de destino (código de barras del hueco) y los contenedores pasan allí.
- El movimiento cambia la ubicación padre del contenedor. Las prendas (quants) y las reservas de los pedidos NO se
  tocan: se conservan tal cual. No crea albaranes ni movimientos de stock.
- Cada movimiento queda apuntado en koroshi.contenedor.movimiento (quién, cuándo, de dónde a dónde, uds).
  Para deshacer: se escanea el mismo contenedor y la ubicación de origen.

Solo escribe en su propia tabla y cambia location_id de la ubicación KO_/TT_ movida. No añade campos a tablas de Odoo.
Segunda parte (aún no hecha): comprobar que una ubicación está a cero y archivar sus contenedores vacíos.

v1.0.0 (13/11/2026): primera versión (mover).
""",
    'version': '13.0.1.0.0',
    'author': 'NATH',
    'category': 'Warehouse',
    'license': 'LGPL-3',
    'depends': ['web', 'stock', 'barcodes', 'koroshi_operarios'],
    'data': [
        'security/ir.model.access.csv',
        'views/assets.xml',
        'views/views.xml',
        'views/menu.xml',
    ],
    'qweb': ['static/src/xml/contenedores.xml'],
    'installable': True,
    'application': False,
}
