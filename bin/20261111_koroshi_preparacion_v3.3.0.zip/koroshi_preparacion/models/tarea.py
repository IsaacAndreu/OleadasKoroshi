# -*- coding: utf-8 -*-
# =============================================================================
# KOROSHI Preparación en Lecturas (v3.3.0) - productividad al preparar a dos.
#
# koroshi_operarios cuenta las uds de una tarea como «uds leídas de la OUT al cerrar - al empezar». Con dos operarios
# en la misma OUT cada uno se contaría también lo del otro. Si en el tiempo de la tarea otro operario ha leído en esta
# pantalla la misma OUT, la tarea cuenta solo las lecturas propias (koroshi.preparacion.lectura, sin las deshechas).
# Solo escribe en koroshi.operario.tarea (uds_inicio / uds_fin / nota).
# =============================================================================
from odoo import fields, models


class KoroshiOperarioTarea(models.Model):
    _inherit = 'koroshi.operario.tarea'

    def _cerrar(self, estado, motivo, fin=None):
        abiertas = self.filtered(lambda t: t.estado == 'curso' and t.tipo == 'out' and t.picking_id)
        res = super(KoroshiOperarioTarea, self)._cerrar(estado, motivo, fin)
        Lectura = self.env['koroshi.preparacion.lectura'].sudo()
        for t in abiertas:
            hasta = t.fin or fields.Datetime.now()
            base = [('picking_id', '=', t.picking_id.id), ('tipo', '=', 'leer'), ('resultado', '=', 'ok'),
                    ('fecha', '>=', t.inicio), ('fecha', '<=', hasta)]
            otros = Lectura.search_count(base + [('employee_id', '!=', False), ('employee_id', '!=', t.employee_id.id)])
            if not otros:
                continue
            propias = Lectura.search(base + [('employee_id', '=', t.employee_id.id), ('deshecha', '=', False)])
            t.write({
                'uds_inicio': 0.0,
                'uds_fin': sum(propias.mapped('cantidad')),
                'nota': ((t.nota or '') + ' Preparada a dos: cuenta solo sus lecturas.').strip(),
            })
        return res
