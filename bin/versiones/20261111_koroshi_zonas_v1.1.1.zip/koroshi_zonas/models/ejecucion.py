# -*- coding: utf-8 -*-
# =============================================================================
# Una ejecucion = un lanzamiento del reparto por zonas (un prefijo de agrupaciones Z-ddmm- o Z-ddmm-R2-).
# Fase 1: MEDIR. Las agrupaciones Z- que ya hay (las hace la accion 1883) se registran como
# ejecuciones de modo 'historico' y se miden sus cajas reales.
# Fase 2: LANZAR el reparto de la v12f (motor/v12f.py) en DIAGNOSTICO, SIMULAR o REAL. Un solo codigo;
# el modo es un campo. SIMULAR y REAL parten dentro de un savepoint: SIMULAR siempre lo deshace y REAL
# lo deshace si falla una comprobacion (todo o nada). La ejecucion queda guardada siempre, con los
# parametros, el contexto, los datos de entrada y el informe.
# =============================================================================
import base64
import datetime
import json
import logging

import pytz

from odoo import api, fields, models

from ..motor import medir as motor_medir
from ..motor import modelo
from ..motor import v12f
from ..motor import volumen
from . import escritor
from . import lector

CLAVES_CONTEXTO = ('personas', 'hora_inicio', 'hora_fin', 'una_ronda', 'zonas', 'zonas_muelle', 'prueba_ids',
                   'prueba_agrupacion')
CANAL_INFORME = 'KOROSHI Partir OUT zonas'     # el canal donde publica hoy la 1881


class _Deshacer(Exception):
    """Para salir del savepoint deshaciendo lo escrito (SIMULAR o comprobaciones que fallan)."""

_logger = logging.getLogger(__name__)

COMPANY_ID = lector.COMPANY_ID
TZ = 'Europe/Madrid'
HISTORICO_DESDE = datetime.date(2026, 10, 22)
DIAS_CRON = 7                   # el cron vuelve a medir los ultimos dias (OUT que se validan tarde)
PARAM_REGLA_DUENO = 'koroshi_zonas.regla_dueno'


class KoroshiZonasEjecucion(models.Model):
    _name = 'koroshi.zonas.ejecucion'
    _description = 'KOROSHI Zonas - ejecución del reparto por zonas'
    _order = 'fecha desc, prefijo desc'

    name = fields.Char('Nombre', readonly=True)   # v1.1.1: se escribe en create/write (antes calculado)
    fecha = fields.Date('Día', required=True, index=True)
    prefijo = fields.Char('Prefijo de agrupaciones', required=True, index=True, help='Z-ddmm- o Z-ddmm-R2-')
    modo = fields.Selection([('historico', 'Histórico (hecha por la acción 1883)'),
                             ('diagnostico', 'Diagnóstico'), ('simular', 'Simular'), ('real', 'Real')],
                            'Modo', required=True, default='historico')
    company_id = fields.Many2one('res.company', 'Compañía', required=True, default=COMPANY_ID)
    out_ids = fields.One2many('koroshi.zonas.ejecucion.out', 'ejecucion_id', 'OUT')

    # Lanzamiento (fase 2)
    estado = fields.Selection([('historico', 'Histórico'), ('diagnostico', 'Diagnóstico (no escribe)'),
                               ('vacio', 'No entra ninguna OUT'), ('pocas_uds', 'Pocas uds: no se parte'),
                               ('simulado', 'Simulado (deshecho)'), ('fallos', 'Fallos: deshecho'),
                               ('error', 'Error: deshecho'), ('hecho', 'Hecho')],
                              'Resultado', default='historico', readonly=True)
    lanzado_el = fields.Datetime('Lanzado el', readonly=True)
    motor = fields.Char('Motor', readonly=True, help='Versión del cálculo: v12f = la de la acción 1883')
    contexto = fields.Text('Contexto', readonly=True, help='personas, horas, zonas, prueba_ids... con los que se lanzó')
    parametros = fields.Text('Parámetros del reparto', readonly=True)
    informe = fields.Text('Informe del reparto', readonly=True)
    datos_entrada = fields.Binary('Datos de entrada', attachment=True, readonly=True,
                                  help='JSON con las OUT y líneas que recibió el motor: reproduce el reparto sin Odoo')
    datos_entrada_nombre = fields.Char('Nombre del fichero de entrada', readonly=True)
    n_out_nuevas = fields.Integer('OUT nuevas', readonly=True)

    # Medicion (fase 1)
    medicion = fields.Selection([('sin_medir', 'Sin medir'), ('parcial', 'En parte (hay OUT sin validar)'),
                                 ('medida', 'Medida')], 'Medición', default='sin_medir', readonly=True)
    medido_el = fields.Datetime('Medido el', readonly=True)
    parametros_medicion = fields.Text('Parámetros de la medición', readonly=True)
    informe_medicion = fields.Text('Informe de la medición', readonly=True)
    n_out = fields.Integer('OUT', readonly=True)
    n_out_medidas = fields.Integer('OUT medidas', readonly=True)
    n_out_cerradas = fields.Integer('OUT en caja cerrada', readonly=True)
    cajas_previstas = fields.Integer('Cajas previstas', readonly=True, help='Solo de las OUT con previsión conocida')
    cajas_estimadas = fields.Integer('Cajas estimadas con lo cogido', readonly=True)
    cajas_reales = fields.Integer('Cajas reales', readonly=True)
    cajas_cerradas = fields.Integer('Cajas cerradas reales', readonly=True)
    cajas_compartidas = fields.Integer('Cajas compartidas', readonly=True)
    pct_cajas_cerradas = fields.Float('% cajas cerradas', readonly=True, digits=(16, 1), group_operator='avg')
    pct_outs_cerradas = fields.Float('% OUT en caja cerrada', readonly=True, digits=(16, 1), group_operator='avg')

    def _nombre(self, prefijo, modo):
        etiqueta = dict(self._fields['modo'].selection)
        return '%s (%s)' % ((prefijo or '').rstrip('-'), etiqueta.get(modo, ''))

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            vals['name'] = self._nombre(vals.get('prefijo'), vals.get('modo') or 'historico')
        return super(KoroshiZonasEjecucion, self).create(vals_list)

    def write(self, vals):
        res = super(KoroshiZonasEjecucion, self).write(vals)
        if 'prefijo' in vals or 'modo' in vals:
            for r in self:
                super(KoroshiZonasEjecucion, r).write({'name': self._nombre(r.prefijo, r.modo)})
        if 'fecha' in vals:     # la fecha de las filas sigue a la de la ejecucion
            self.mapped('out_ids').write({'fecha': vals['fecha']})
        return res

    @api.model
    def _rellenar_campos(self):
        """v1.1.1: rellena lo que la v1.1.0 dejo vacio (nombre de la ejecucion; dia, compania, diferencia y
        causa de las filas). Se llama al actualizar el modulo (data/rellenar.xml); no hace nada si ya esta."""
        for ej in self.sudo().search([]):
            nombre = self._nombre(ej.prefijo, ej.modo)
            if ej.name != nombre:
                super(KoroshiZonasEjecucion, ej).write({'name': nombre})
            filas = ej.out_ids.filtered(lambda f: f.fecha != ej.fecha or f.company_id != ej.company_id)
            if filas:
                filas.write({'fecha': ej.fecha, 'company_id': ej.company_id.id})
            ej.out_ids.filtered(lambda f: not f.causa)._escribir_causa()
        return True

    # ------------------------------------------------------------------ parametros
    def _medidas(self):
        return volumen.Medidas()

    def _regla_dueno(self):
        regla = self.env['ir.config_parameter'].sudo().get_param(PARAM_REGLA_DUENO, 'primera_linea')
        return regla in motor_medir.REGLAS_DUENO and regla or 'primera_linea'

    # ------------------------------------------------------------------ registrar OUT
    @api.model
    def _rango_utc(self, desde, hasta):
        tz = pytz.timezone(TZ)
        ini = tz.localize(datetime.datetime.combine(desde, datetime.time.min)).astimezone(pytz.utc)
        fin = tz.localize(datetime.datetime.combine(hasta + datetime.timedelta(days=1),
                                                    datetime.time.min)).astimezone(pytz.utc)
        return ini.replace(tzinfo=None), fin.replace(tzinfo=None)

    @api.model
    def registrar_rango(self, desde, hasta):
        """Crea (o completa) las ejecuciones y sus filas de OUT de las agrupaciones Z- creadas entre
        esas fechas (hora de Espana). Lee la prevision (CAJAS n) de la nota: si ya estaba leida, no la pisa."""
        ini, fin = self._rango_utc(desde, hasta)
        lotes = self.env['stock.picking.batch'].sudo().search([
            ('company_id', '=', COMPANY_ID), ('name', '=like', 'Z-%'),
            ('create_date', '>=', ini), ('create_date', '<', fin)], order='create_date, id')
        por_prefijo = {}
        for lote in lotes:
            partes = lector.partir_nombre_lote(lote.name)
            if partes:
                por_prefijo.setdefault(partes[0], []).append((lote, partes[1]))
        tz = pytz.timezone(TZ)
        ejecuciones = self.browse()
        for prefijo, lista in por_prefijo.items():
            primero = lista[0][0]
            fecha = pytz.utc.localize(primero.create_date).astimezone(tz).date()
            ej = self.search([('prefijo', '=', prefijo), ('company_id', '=', COMPANY_ID),
                              ('estado', 'in', ('historico', 'hecho'))], limit=1)
            if not ej:
                ej = self.create({'prefijo': prefijo, 'fecha': fecha, 'modo': 'historico'})
            ej._registrar_outs(lista)
            ejecuciones |= ej
        return ejecuciones

    def _registrar_outs(self, lista):
        self.ensure_one()
        Fila = self.env['koroshi.zonas.ejecucion.out'].sudo()
        ya = {}
        for f in self.out_ids:
            ya[f.picking_id.id] = f
        for lote, zona in lista:
            for p in lote.picking_ids:
                if p.state == 'cancel' or p.picking_type_code != 'outgoing' or p.company_id.id != COMPANY_ID:
                    continue
                previstas = lector.cajas_de_nota(p.note)
                fila = ya.get(p.id)
                if fila:
                    if not fila.prevision_conocida and previstas is not None:
                        fila.write({'cajas_previstas': previstas, 'prevision_conocida': True})
                    continue
                ya[p.id] = Fila.create({
                    'ejecucion_id': self.id,
                    'picking_id': p.id,
                    'lote_id': lote.id,
                    'zona': zona,
                    'pedido': p.origin or '',
                    'tienda': p.partner_id.name or '',
                    'cajas_previstas': previstas or 0,
                    'prevision_conocida': previstas is not None,
                })

    # ------------------------------------------------------------------ medir
    def action_medir(self):
        # Cada ejecucion en su savepoint: si una falla no queda a medias y las demas se miden igual.
        # Solo se miden las que han partido OUT de verdad (historico y REAL hecho).
        for ej in self.filtered(lambda e: e.modo == 'historico' or (e.modo == 'real' and e.estado == 'hecho')):
            try:
                with self.env.cr.savepoint():
                    ej._medir()
            except Exception:
                _logger.exception('KOROSHI Zonas: no se ha podido medir %s', ej.prefijo)
                if len(self) == 1:
                    raise
        return True

    def _medir(self):
        self.ensure_one()
        medidas = self._medidas()
        regla = self._regla_dueno()
        filas = self.out_ids
        picks = filas.mapped('picking_id')
        lineas = lector.lineas_para_medir(self.env, picks, medidas)
        por_out, por_caja = motor_medir.medir(lineas, picks.ids, medidas, regla)
        hechas = set(picks.filtered(lambda p: p.state == 'done').ids)
        for f in filas:
            r = por_out.get(f.picking_id.id)
            f.write({
                'medida': f.picking_id.id in hechas,
                'uds': r['uds'],
                'litros': r['litros'],
                'cajas_estimadas': r['cajas_estimadas'],
                'cerrada_estimada': r['cerrada_estimada'],
                'cajas_reales': r['cajas_reales'],
                'cajas_cerradas': r['cajas_cerradas'],
                'cajas_compartidas': r['cajas_compartidas'],
                'cajas_ajenas': r['cajas_ajenas'],
                'uds_en_ajenas': r['uds_en_ajenas'],
                'uds_sin_caja': r['uds_sin_caja'],
                'cerrada': r['cerrada'],
            })
        medidas_out = {}
        previstas = {}
        zona_de = {}
        for f in filas:
            pid = f.picking_id.id
            zona_de[pid] = f.zona or ''
            if pid in hechas:
                medidas_out[pid] = por_out[pid]
                if f.prevision_conocida:
                    previstas[pid] = f.cajas_previstas
        tot = motor_medir.resumen(medidas_out, previstas)
        por_zona = {}
        for zona in sorted(set(zona_de.values())):
            sub = {}
            for pid in medidas_out:
                if zona_de[pid] == zona:
                    sub[pid] = medidas_out[pid]
            por_zona[zona] = motor_medir.resumen(sub, previstas)
        g = tot['grupos']
        self.write({
            'medicion': (not hechas and 'sin_medir') or (len(hechas) < len(picks) and 'parcial') or 'medida',
            'medido_el': fields.Datetime.now(),
            'parametros_medicion': json.dumps({'medidas': medidas.como_dict(), 'regla_dueno': regla},
                                              sort_keys=True),
            'informe_medicion': self._texto_informe(tot, por_zona, filas, regla, medidas),
            'n_out': len(picks),
            'n_out_medidas': tot['outs'],
            'n_out_cerradas': tot['outs_cerradas'],
            'cajas_previstas': g['limpias']['previstas'] + g['con_compartida']['previstas'],
            'cajas_estimadas': g['limpias']['estimadas'] + g['con_compartida']['estimadas'],
            'cajas_reales': tot['cajas_reales'],
            'cajas_cerradas': tot['cajas_cerradas'],
            'cajas_compartidas': tot['cajas_compartidas'],
            'pct_cajas_cerradas': tot['pct_cajas_cerradas'],
            'pct_outs_cerradas': tot['pct_outs_cerradas'],
        })

    def _texto_informe(self, tot, por_zona, filas, regla, medidas):
        lin = []
        lin.append('MEDICION %s - %s' % (self.prefijo, self.fecha and self.fecha.strftime('%d/%m/%Y') or ''))
        lin.append('Caja de %d L; cerrada si no es compartida y lleva al menos el %d%%. Dueno de caja compartida: %s.' % (
            medidas.litros_caja, round(medidas.cierre_min * 100), regla))
        lin.append('OUT medidas: %d | en caja cerrada: %d (%.1f%%) | cajas reales %d | cerradas %d (%.1f%%) | '
                   'compartidas %d' % (tot['outs'], tot['outs_cerradas'], tot['pct_outs_cerradas'],
                                       tot['cajas_reales'], tot['cajas_cerradas'], tot['pct_cajas_cerradas'],
                                       tot['cajas_compartidas']))
        lin.append('')
        lin.append('Por zona: OUT | cajas reales | cerradas | % | compartidas')
        for zona in sorted(por_zona):
            z = por_zona[zona]
            lin.append('   %-5s %4d OUT | %4d cajas | %4d cerradas | %5.1f%% | %d compartidas' % (
                zona, z['outs'], z['cajas_reales'], z['cajas_cerradas'], z['pct_cajas_cerradas'],
                z['cajas_compartidas']))
        lin.append('')
        lin.append('Previsto contra real (solo OUT con CAJAS n en la nota):')
        for clave, titulo in (('limpias', 'OUT limpias (error del modelo de litros y de lo cogido)'),
                              ('con_compartida', 'OUT con caja compartida (caja existente)')):
            g = tot['grupos'][clave]
            lin.append('   %s: %d OUT (%d con prevision) | previstas %d | estimadas con lo cogido %d | reales %d' % (
                titulo, g['outs'], g['outs_con_prevision'], g['previstas'], g['estimadas_con_prevision'],
                g['reales_con_prevision']))
        sin_prev = len(filas.filtered(lambda f: not f.prevision_conocida))
        if sin_prev:
            lin.append('   %d OUT sin CAJAS n en la nota (pisada por otro proceso)' % sin_prev)
        distintas = filas.filtered(lambda f: f.medida and f.prevision_conocida and f.diferencia)
        if distintas:
            lin.append('')
            lin.append('OUT con cajas reales distintas de las previstas (%d):' % len(distintas))
            for f in distintas.sorted(lambda x: (x.zona or '', x.picking_id.name))[:80]:
                lin.append('   %s | %s | %s | previstas %d, estimadas %d, reales %d | %s' % (
                    f.zona or '', f.picking_id.name, f.tienda or '', f.cajas_previstas, f.cajas_estimadas,
                    f.cajas_reales, dict(f._fields['causa'].selection).get(f.causa, '')))
            if len(distintas) > 80:
                lin.append('   ... y %d mas' % (len(distintas) - 80))
        return '\n'.join(lin)

    # ------------------------------------------------------------------ crons y acciones
    @api.model
    def _hoy(self):
        return datetime.datetime.now(pytz.timezone(TZ)).date()

    @api.model
    def cron_capturar(self):
        """Cada hora: registra las OUT de las agrupaciones Z- de hoy y lee el CAJAS n de su nota antes de
        que otro proceso la pise. No mide."""
        hoy = self._hoy()
        self.registrar_rango(hoy, hoy)
        return True

    @api.model
    def cron_medir(self):
        """Cada noche: registra y mide los ultimos DIAS_CRON dias."""
        hoy = self._hoy()
        self.registrar_rango(hoy - datetime.timedelta(days=DIAS_CRON), hoy).action_medir()
        return True

    @api.model
    def medir_historico(self):
        """Registra y mide todo desde HISTORICO_DESDE (22/10/2026). Se puede lanzar las veces que haga falta."""
        ejecuciones = self.registrar_rango(HISTORICO_DESDE, self._hoy())
        ejecuciones.action_medir()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Ejecuciones medidas',
            'res_model': 'koroshi.zonas.ejecucion',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', ejecuciones.ids)],
        }

    # ------------------------------------------------------------------ lanzar el reparto (fase 2)
    @api.model
    def lanzar(self, modo, contexto=None):
        """Reparto de la v12f. modo: 'DIAGNOSTICO', 'SIMULAR' o 'REAL'. contexto: personas, hora_inicio,
        hora_fin, una_ronda, zonas, zonas_muelle, prueba_ids, prueba_agrupacion (como la accion 1883;
        con prueba_ids o prueba_agrupacion siempre es DIAGNOSTICO). Devuelve la ejecucion."""
        modo = (modo or '').upper()
        if modo not in ('DIAGNOSTICO', 'SIMULAR', 'REAL'):
            raise ValueError('Modo desconocido: %s' % modo)
        contexto = dict((k, v) for k, v in (contexto or {}).items() if k in CLAVES_CONTEXTO)
        cambios = {'MODO': modo}
        p = modelo.parametros(cambios, contexto)
        ahora = datetime.datetime.now(pytz.timezone(p['ZONA_HORARIA']))
        datos = lector.datos_reparto(self.env, contexto, ahora, p)
        datos['contexto'] = contexto
        rep = v12f.repartir(datos, cambios, contexto)
        ej = self.create({
            'modo': rep.modo.lower(),
            'fecha': ahora.date(),
            'prefijo': rep.prefijo,
            'motor': 'v12f',
            'lanzado_el': fields.Datetime.now(),
            'contexto': json.dumps(contexto, sort_keys=True),
            'parametros': json.dumps(rep.parametros, sort_keys=True, default=list),
            'datos_entrada': base64.b64encode(json.dumps(datos).encode('utf-8')),
            'datos_entrada_nombre': 'koroshi_zonas_%s_%s.json' % (ahora.strftime('%Y%m%d_%H%M'), rep.modo.lower()),
        })
        lineas = list(rep.lineas)
        out_de = None
        n_nuevas = 0
        if rep.estado != 'listo':
            estado = rep.estado
        elif rep.modo == 'DIAGNOSTICO':
            estado = 'diagnostico'
        else:
            estado = 'error'
            fallos = []
            try:
                with self.env.cr.savepoint():
                    extra, fallos, todas_out, out_de = escritor.aplicar(self.env, rep)
                    lineas += extra
                    n_nuevas = len(todas_out) - len(rep.plan)
                    self.env['base'].flush()
                    if fallos:
                        lineas.insert(0, 'NO SE HA HECHO NADA (se ha deshecho todo)')
                        raise _Deshacer()
                    if rep.modo != 'REAL':
                        lineas.append('')
                        lineas.append('SIMULACION: se ha deshecho todo. Para hacerlo de verdad: modo REAL.')
                        raise _Deshacer()
                    lineas[0] = 'KOROSHI PARTIR OUT ZONAS v12 CAJA CERRADA - HECHO'
                    estado = 'hecho'
            except _Deshacer:
                estado = fallos and 'fallos' or 'simulado'
            except Exception as e:
                _logger.exception('KOROSHI Zonas: error al partir (%s)', rep.modo)
                lineas.insert(0, 'NO SE HA HECHO NADA (error: %s; se ha deshecho todo)' % e)
            if estado != 'hecho':
                out_de = None
                n_nuevas = 0
                self.env.cache.invalidate()
        ej._filas_plan(rep, out_de)
        ej.write({'informe': '\n'.join(lineas), 'estado': estado, 'n_out_nuevas': n_nuevas})
        _logger.info('\n'.join(lineas))
        ej._publicar()
        return ej

    def _filas_plan(self, rep, out_de):
        """Una fila por OUT y zona del plan. Sin partir (DIAGNOSTICO, SIMULAR, deshecho): la OUT original.
        Hecho: la OUT que ha quedado en cada zona, con su agrupacion."""
        self.ensure_one()
        Fila = self.env['koroshi.zonas.ejecucion.out'].sudo()
        for pid, por_z, principal, sin_res, caja in rep.plan:
            out = rep.calc.out_rec[pid]
            for zn in rep.orden_zonas:
                if zn not in por_z:
                    continue
                pick = out_de and out_de.get((pid, zn)) or None
                Fila.create({
                    'ejecucion_id': self.id,
                    'picking_id': pick and pick.id or pid,
                    'lote_id': pick and pick.batch_id.id or False,
                    'zona': zn,
                    'pedido': out['origin'] or '',
                    'tienda': out['partner_name'] or '',
                    'cajas_previstas': por_z[zn][0],
                    'prevision_conocida': True,
                })

    def _publicar(self):
        """Publica el informe en el canal de Conversaciones de la 1881, si existe. Si falla, sigue."""
        try:
            canal = self.env['mail.channel'].sudo().search([('name', '=', CANAL_INFORME)], limit=1)
            if canal:
                cuerpo = (self.informe or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
                canal.message_post(body='<pre style="font-size:12px">' + cuerpo + '</pre>', message_type='comment',
                                   subtype='mail.mt_comment')
        except Exception as e:
            _logger.warning('KOROSHI Zonas: no se ha podido publicar el informe en el canal: %s', e)

    def accion_abrir(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': self.name,
            'res_model': 'koroshi.zonas.ejecucion',
            'view_mode': 'form',
            'res_id': self.id,
        }

    @api.model
    def accion_lanzar_hoy(self, modo):
        return self.lanzar(modo, self.env.context).accion_abrir()

    @api.model
    def accion_diagnostico_ids(self, ids):
        return self.lanzar('DIAGNOSTICO', dict(self.env.context, prueba_ids=ids)).accion_abrir()
