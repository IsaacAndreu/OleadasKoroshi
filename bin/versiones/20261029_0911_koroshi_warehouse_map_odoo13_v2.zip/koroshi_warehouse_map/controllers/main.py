# -*- coding: utf-8 -*-
import datetime
import json
import re

from odoo import fields, http
from odoo.http import request


COMPANY_ID = 8  # EFFECTIVE LOGISTICS, S.L.
LINE_RE = re.compile(r'\bL(\d{1,3})\b', re.IGNORECASE)
POSITION_RE = re.compile(r'\bP(\d{1,3})\b', re.IGNORECASE)
LEVEL_RE = re.compile(r'\bC([1-4])\b', re.IGNORECASE)


class KoroshiWarehouseMapController(http.Controller):
    """Endpoints de lectura para la vista operativa del mapa.

    Esta primera versión no modifica albaranes, movimientos ni stock. Lee las
    sesiones propias del módulo y, si todavía no hay sesiones de PDA, muestra
    una aproximación basada en las OUT activas de Odoo.
    """

    def _company(self):
        company = request.env['res.company'].sudo().browse(COMPANY_ID).exists()
        return company or request.env.user.company_id

    def _time(self, value):
        if not value:
            return ''
        local = fields.Datetime.context_timestamp(request.env.user, value)
        return local.strftime('%H:%M')

    def _location_parts(self, value):
        value = value or ''
        line = LINE_RE.search(value)
        position = POSITION_RE.search(value)
        level = LEVEL_RE.search(value)
        return (
            line.group(0).upper() if line else '',
            position.group(0).upper() if position else '',
            ('C' + level.group(1)) if level else '',
        )

    def _marker(self, key, location, index):
        line, position, level = self._location_parts(location)
        line_number = int(line[1:]) if line else 0
        position_number = int(position[1:]) if position else 0
        if line_number:
            x = 10 + ((line_number - 1) % 16) * 5.2
            y = 22 + ((line_number - 1) // 16) * 9
        else:
            x = 18 + (index * 17) % 68
            y = 25 + (index * 23) % 58
        return {
            'x': min(max(round(x, 1), 7), 93),
            'y': min(max(round(y, 1), 12), 88),
            'line': line,
            'position': position,
            'level': level,
            'position_number': position_number,
            'key': key,
        }

    def _session_row(self, session, index):
        picking = session.picking_id
        location = session.last_location or session.last_line or ''
        marker = self._marker(session.id, location, index)
        state = session.state
        status = {
            'picking': 'En picking',
            'paused': 'En pausa',
            'done': 'Finalizado',
            'cancelled': 'Cancelado',
        }.get(state, 'Sin empezar')
        timeline = []
        for event in session.event_ids.sorted(
                key=lambda item: item.occurred_at or datetime.datetime.min)[-8:]:
            timeline.append([
                self._time(event.occurred_at),
                dict(self.env_event_types()).get(event.event_type, event.event_type),
                event.location or session.last_location or '',
            ])
        return {
            'id': 'session-%s' % session.id,
            'initials': (session.operator_name or session.user_id.name or 'PDA')[:2].upper(),
            'name': session.operator_name or session.user_id.name or 'PDA sin asignar',
            'pda': session.pda_code or 'PDA —',
            'out': session.out_reference or (picking.name if picking else session.name),
            'status': status,
            'location': location or 'Sin ubicación',
            'start': self._time(session.started_at),
            'lastPick': location or '—',
            'lastAt': self._time(session.last_scan_at),
            'finish': self._time(session.finished_at) or '—',
            'progress': round(session.progress or 0.0),
            'picks': session.pick_count or 0,
            'x': marker['x'],
            'y': marker['y'],
            'color': self._color(state),
            'timeline': timeline,
            'source': session.source or 'pda',
        }

    def env_event_types(self):
        return {
            'start': 'Inicio del OUT',
            'pick': 'Pick confirmado',
            'pause': 'Pausa detectada',
            'resume': 'Reanudación',
            'finish': 'OUT finalizado',
            'scan': 'Último escaneo',
        }

    def _color(self, state):
        return {
            'picking': '#22c55e',
            'paused': '#ffd040',
            'done': '#8ab8d8',
            'cancelled': '#f87171',
        }.get(state, '#4da8ff')

    def _picking_row(self, picking, index):
        move_line_domain = [('picking_id', '=', picking.id), ('qty_done', '>', 0)]
        move_count = request.env['stock.move.line'].sudo().search_count(move_line_domain)
        move_lines = request.env['stock.move.line'].sudo().search(
            move_line_domain,
            order='write_date desc, id desc', limit=1,
        )
        last_line = move_lines[:1]
        location = ''
        last_at = None
        if last_line:
            location = last_line.location_id.complete_name or last_line.location_id.name or ''
            last_at = last_line.write_date
        moves = request.env['stock.move'].sudo().search([('picking_id', '=', picking.id)])
        total = sum(move.product_uom_qty or 0.0 for move in moves)
        done = sum(move.quantity_done or 0.0 for move in moves)
        progress = (done / total * 100.0) if total else 0.0
        state = 'done' if picking.state == 'done' else (
            'picking' if picking.state in ('assigned', 'confirmed', 'partially_available') else 'draft'
        )
        marker = self._marker(picking.id, location, index)
        responsible = getattr(picking, 'user_id', False)
        name = responsible.name if responsible else 'OUT sin persona asignada'
        return {
            'id': 'picking-%s' % picking.id,
            'initials': name[:2].upper(),
            'name': name,
            'pda': 'Odoo',
            'out': picking.name,
            'status': {'picking': 'En picking', 'done': 'Finalizado'}.get(state, 'Sin empezar'),
            'location': location or 'Sin escaneo',
            'start': self._time(picking.date),
            'lastPick': location or '—',
            'lastAt': self._time(last_at),
            'finish': self._time(picking.date_done) or '—',
            'progress': round(progress),
            'picks': move_count,
            'x': marker['x'],
            'y': marker['y'],
            'color': self._color(state),
            'timeline': [],
            'source': 'odoo',
        }

    @http.route('/koroshi_warehouse_map/layout/save', type='http', auth='user',
                methods=['POST'], csrf=False)
    def save_layout(self, **kwargs):
        """Guarda un layout en las tablas propias del módulo.

        No toca el plano base ni ninguna tabla de stock. El navegador sigue
        guardando localmente para no perder el trabajo si la red falla y, si
        la sesión de Odoo está disponible, deja una copia en koroshi.layout.
        """
        try:
            raw = request.httprequest.get_data(as_text=True) or '{}'
            values = json.loads(raw)
            if not isinstance(values, dict):
                raise ValueError('Formato de layout no válido')
        except (TypeError, ValueError, json.JSONDecodeError) as error:
            return request.make_response(
                json.dumps({'ok': False, 'error': str(error)}),
                status=400,
                headers=[('Content-Type', 'application/json; charset=utf-8')],
            )
        data = values.get('data') or {}
        if not isinstance(data, dict):
            return request.make_response(
                json.dumps({'ok': False, 'error': 'Los datos deben ser un objeto JSON'}),
                status=400,
                headers=[('Content-Type', 'application/json; charset=utf-8')],
            )
        company = self._company()
        name = str(values.get('name') or 'Diseño NAU-2')[:120]
        stamp = fields.Datetime.now().replace('-', '').replace(':', '').replace(' ', '_')
        layout = request.env['koroshi.layout'].sudo().create({
            'name': name,
            'code': 'NAU2-%s-%s' % (request.env.user.id, stamp),
            'company_id': company.id,
            'source_version': 'NAU-2 · 2026-10-29',
            'map_json': json.dumps(data, ensure_ascii=False),
        })
        body = json.dumps({'ok': True, 'layout_id': layout.id, 'name': layout.name},
                          ensure_ascii=False)
        return request.make_response(body, headers=[
            ('Content-Type', 'application/json; charset=utf-8'),
            ('Cache-Control', 'no-store'),
        ])

    @http.route('/koroshi_warehouse_map/data', type='http', auth='user',
                methods=['GET'], csrf=False)
    def data(self, **kwargs):
        company = self._company()
        Session = request.env['koroshi.pick.session'].sudo()
        sessions = Session.search([
            ('company_id', '=', company.id),
            ('active', '=', True),
        ], limit=200)
        if sessions:
            people = [self._session_row(session, index)
                      for index, session in enumerate(sessions)]
            source = 'ODOO · sesiones PDA'
        else:
            Picking = request.env['stock.picking'].sudo()
            pickings = Picking.search([
                ('company_id', '=', company.id),
                ('picking_type_code', '=', 'outgoing'),
                ('state', 'not in', ('cancel',)),
            ], order='write_date desc, id desc', limit=40)
            people = [self._picking_row(picking, index)
                      for index, picking in enumerate(pickings)]
            source = 'ODOO · OUTs'
        payload = {
            'ok': True,
            'source': source,
            'updated_at': fields.Datetime.now(),
            'company_id': company.id,
            'people': people,
        }
        body = json.dumps(payload, default=str, ensure_ascii=False)
        return request.make_response(body, headers=[
            ('Content-Type', 'application/json; charset=utf-8'),
            ('Cache-Control', 'no-store'),
        ])
