# -*- coding: utf-8 -*-
# =============================================================================
# KOROSHI Faltantes - datos de la pantalla "Faltante" de la PDA (accion de cliente
# koroshi_faltantes_pantalla, static/src/js/faltantes_pantalla.js). Usuario con sesion (p. ej. "Almacen Nath").
#
# JSON /koroshi/faltantes/buscar           {codigo, out_id, move_line_id}   -> tarjeta, OUT, lineas o linea
# JSON /koroshi/faltantes/reubicar         {move_line_id, codigo, employee_id} -> cambia la reserva + FALTANT
# JSON /koroshi/faltantes/sin_alternativa  {move_line_id, employee_id}      -> quita la reserva + FALTANT
#
# Lee y escribe con el usuario de la sesion (derechos normales de almacen). La tarjeta del operario se busca
# con sudo en todas las empresas, como en koroshi_operarios.
# =============================================================================
from odoo import http
from odoo.exceptions import UserError, ValidationError
from odoo.http import request

from ..models.faltante import PREFIJOS_ZONA, nombre_corto


def _msg(e):
    return e.name if hasattr(e, 'name') else str(e)


def _out_json(picking):
    batch = picking.batch_id
    zona = bool(batch and (batch.name or '').startswith(PREFIJOS_ZONA))
    return {
        'id': picking.id,
        'name': picking.name,
        'tienda': picking.partner_id.name or '',
        'batch_id': batch.id if zona else False,
        'batch_name': batch.name if zona else '',
    }


def _linea_json(ml, Faltante, con_alternativas=False):
    res = {
        'id': ml.id,
        'producto': ml.product_id.display_name,
        'ean': ml.product_id.barcode or '',
        'cantidad': ml.product_uom_qty,
        'leidas': ml.qty_done,
        'ubicacion': nombre_corto(ml.location_id),
        'ubicacion_completa': ml.location_id.complete_name,
        'motivo': Faltante.comprobar_linea(ml),
    }
    if con_alternativas and not res['motivo']:
        raiz = Faltante._raiz_stock(ml.picking_id)
        alt = Faltante.alternativas(ml.product_id, ml.location_id, raiz)
        res['alternativas'] = alt['lista']
        res['alternativas_total'] = alt['total']
    return res


def _empleado_json(emp):
    return {'id': emp.id, 'nombre': emp.name} if emp else False


class KoroshiFaltantes(http.Controller):

    # ------------------------------------------------------------------ ayudas
    def _tarjeta(self, codigo):
        return request.env['hr.employee'].sudo().search([('barcode', '=', codigo)], limit=1)

    def _operario(self, employee_id, picking=None):
        """El de la tarjeta leida o, si no hay, el de la tarea abierta de esa OUT o agrupacion."""
        emp = request.env['hr.employee'].sudo().browse(int(employee_id or 0)).exists()
        if emp or not picking:
            return emp
        Tarea = request.env['koroshi.operario.tarea'].sudo()
        dom = [('estado', '=', 'curso'), '|', ('picking_id', '=', picking.id)]
        dom += [('batch_id', '=', picking.batch_id.id)] if picking.batch_id else [('id', '=', 0)]
        return Tarea.search(dom, order='inicio desc', limit=1).employee_id

    def _picking(self, codigo):
        Picking = request.env['stock.picking']
        pk = Picking.search([('name', '=', codigo)], limit=1)
        if not pk and codigo.isdigit() and len(codigo) <= 6:     # solo el numero: 23649 -> EFFEC/OUT/23649
            pks = Picking.search([('name', '=like', '%/' + codigo)], limit=2)
            pk = pks if len(pks) == 1 else Picking
        return pk

    def _producto(self, codigo):
        Product = request.env['product.product']
        return (Product.search([('barcode', '=', codigo)], limit=1) or
                Product.search([('default_code', '=', codigo)], limit=1))

    def _ubicacion(self, codigo, company):
        Loc = request.env['stock.location']
        dom = [('company_id', 'in', [company.id, False])]
        return (Loc.search([('barcode', '=', codigo)] + dom, limit=1) or
                Loc.search([('name', '=', codigo), ('usage', '=', 'internal')] + dom, limit=1))

    def _linea(self, move_line_id):
        return request.env['stock.move.line'].browse(int(move_line_id or 0)).exists()

    # ------------------------------------------------------------------ rutas
    @http.route('/koroshi/faltantes/buscar', type='json', auth='user')
    def buscar(self, codigo='', out_id=False, move_line_id=False, employee_id=False, **kw):
        Faltante = request.env['koroshi.faltante']
        codigo = (codigo or '').strip()
        try:
            # una linea concreta (cuando la OUT tiene varias del mismo articulo)
            if move_line_id and not codigo:
                ml = self._linea(move_line_id)
                if not ml:
                    return {'ok': False, 'msg': 'La linea ya no existe. Vuelve a leer la OUT.'}
                return {'ok': True, 'que': 'linea', 'out': _out_json(ml.picking_id),
                        'linea': _linea_json(ml, Faltante, con_alternativas=True)}
            if not codigo:
                return {'ok': False, 'msg': 'Codigo vacio'}

            emp = self._tarjeta(codigo)
            if emp:
                return {'ok': True, 'que': 'tarjeta', 'operario': _empleado_json(emp)}

            picking = self._picking(codigo)
            if picking:
                if picking.state in ('done', 'cancel'):
                    return {'ok': False, 'msg': 'La OUT %s ya esta %s.' % (
                        picking.name, 'validada' if picking.state == 'done' else 'cancelada')}
                return {'ok': True, 'que': 'out', 'out': _out_json(picking),
                        'operario': _empleado_json(self._operario(employee_id, picking))}

            picking = request.env['stock.picking'].browse(int(out_id or 0)).exists()
            if not picking:
                return {'ok': False, 'msg': 'No encuentro la OUT %s. Lee primero la OUT.' % codigo}

            product = self._producto(codigo)
            if not product:
                return {'ok': False, 'msg': 'No encuentro el articulo %s.' % codigo}
            lineas = picking.move_line_ids.filtered(
                lambda l: l.product_id == product and l.state not in ('done', 'cancel'))
            if not lineas:
                return {'ok': False, 'msg': 'El articulo %s no esta en la OUT %s.' % (product.display_name,
                                                                                   picking.name)}
            libres = lineas.filtered(lambda l: not Faltante.comprobar_linea(l))
            if len(libres) == 1:
                return {'ok': True, 'que': 'linea', 'out': _out_json(picking),
                        'linea': _linea_json(libres, Faltante, con_alternativas=True)}
            if not libres:
                return {'ok': False, 'msg': Faltante.comprobar_linea(lineas[0])}
            return {'ok': True, 'que': 'lineas', 'out': _out_json(picking),
                    'lineas': [_linea_json(l, Faltante) for l in libres]}
        except (UserError, ValidationError) as e:
            return {'ok': False, 'msg': _msg(e)}

    @http.route('/koroshi/faltantes/reubicar', type='json', auth='user')
    def reubicar(self, move_line_id=False, codigo='', employee_id=False, **kw):
        Faltante = request.env['koroshi.faltante']
        codigo = (codigo or '').strip()
        if not codigo:
            return {'ok': False, 'msg': 'Codigo vacio'}
        emp = self._tarjeta(codigo)
        if emp:
            return {'ok': True, 'que': 'tarjeta', 'operario': _empleado_json(emp)}
        ml = self._linea(move_line_id)
        if not ml:
            return {'ok': False, 'msg': 'La linea ya no existe. Vuelve a leer la OUT.'}
        ubicacion = self._ubicacion(codigo, ml.picking_id.company_id)
        if not ubicacion:
            return {'ok': False, 'msg': '%s no es una ubicacion. Lee la ubicacion de donde coges la pieza.'
                                        % codigo}
        picking = ml.picking_id
        try:
            f = Faltante.reubicar(ml, ubicacion, self._operario(employee_id, picking))
        except (UserError, ValidationError) as e:
            return {'ok': False, 'msg': _msg(e)}
        texto = 'Hecho: la linea pasa a %s.' % nombre_corto(f.ubicacion_nueva_id)
        texto += ' %s ud a FALTANT.' % f.cantidad_faltant if f.cantidad_faltant else ''
        return {'ok': True, 'que': 'hecho', 'msg': texto, 'nota': f.nota or '', 'out': _out_json(picking),
                'faltante_id': f.id}

    @http.route('/koroshi/faltantes/sin_alternativa', type='json', auth='user')
    def sin_alternativa(self, move_line_id=False, employee_id=False, **kw):
        Faltante = request.env['koroshi.faltante']
        ml = self._linea(move_line_id)
        if not ml:
            return {'ok': False, 'msg': 'La linea ya no existe. Vuelve a leer la OUT.'}
        picking = ml.picking_id
        try:
            f = Faltante.sin_alternativa(ml, self._operario(employee_id, picking))
        except (UserError, ValidationError) as e:
            return {'ok': False, 'msg': _msg(e)}
        texto = 'Hecho: la linea queda sin reserva; la OUT se valida sin esta pieza.'
        texto += ' %s ud a FALTANT.' % f.cantidad_faltant if f.cantidad_faltant else ''
        return {'ok': True, 'que': 'hecho', 'msg': texto, 'nota': f.nota or '', 'out': _out_json(picking),
                'faltante_id': f.id}
