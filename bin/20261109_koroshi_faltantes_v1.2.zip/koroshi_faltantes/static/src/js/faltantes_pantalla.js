odoo.define('koroshi_faltantes.Pantalla', function (require) {
'use strict';
/* KOROSHI Faltantes v1.2 - pantalla "Faltante" de la PDA (accion de cliente koroshi_faltantes_pantalla).
 *
 * Pasos: OUT -> EAN -> (linea, si hay varias) -> ubicacion de donde se coge.
 *   - Muestra donde estaba reservada y hasta 5 ubicaciones con stock libre (lineal mas cercano primero).
 *   - Al leer la ubicacion: /koroshi/faltantes/reubicar (la linea pasa alli y la que falta va a FALTANT).
 *   - "No esta en ningun sitio" (dos pulsaciones): /koroshi/faltantes/sin_alternativa.
 *   - "Volver a la OUT": la abre en la app de codigo de barras como koroshi_operarios.
 * La tarjeta del operario se puede leer en cualquier momento; si no, se usa el de la tarea abierta de la OUT.
 * Lecturas por el bus 'barcode_scanned' (solo si la pantalla se ve) o escribiendo y Enter.
 * Si se abrio desde la pantalla de Operarios, al volver de la OUT regresa a Operarios.
 * v1.2: desde Operarios v2 ya viene la OUT que esta haciendo el operario: se empieza en el paso del EAN.
 * No cambia la app de codigo de barras.
 */
var AbstractAction = require('web.AbstractAction');
var core = require('web.core');

var REPETIDA_MS = 700;        // la misma lectura dos veces seguidas (bus + campo) cuenta una
var CONFIRMAR_MS = 5000;      // tiempo para la segunda pulsacion de "No esta en ningun sitio"

var Pantalla = AbstractAction.extend({
    contentTemplate: 'koroshi_faltantes.Pantalla',
    events: {
        'keydown .o_kf_codigo': '_onKeydown',
        'click .o_kf_nada': '_onNada',
        'click .o_kf_volver': '_onVolver',
        'click .o_kf_otro': '_onOtro',
        'click .o_kf_nuevo': '_onNuevo',
        'click .o_kf_salir': '_onSalir',
        'click .o_kf_elegir': '_onElegirLinea',
    },

    init: function (parent, action) {
        this._super.apply(this, arguments);
        var ctx = (action && action.context) || {};
        this.desdeOperarios = !!ctx.desde_operarios;
        // v1.2: desde Operarios v2 llega la OUT que esta haciendo y el operario: solo hay que leer el EAN
        this.outInicial = ctx.faltante_out || false;
        this.operarioInicial = ctx.faltante_operario || null;
        this.ocupado = false;
        this.ultima = {codigo: '', t: 0};
        this.operario = null;      // {id, nombre, tarjeta: bool}
        this.abrioOut = false;
        this._limpiar();
    },

    start: function () {
        var self = this;
        core.bus.on('barcode_scanned', this, this._onBarcodeScanned);
        return this._super.apply(this, arguments).then(function () {
            if (self.operarioInicial && self.operarioInicial.id) {
                self.operario = {id: self.operarioInicial.id, nombre: self.operarioInicial.nombre, tarjeta: true};
            }
            self._pintar();
            if (self.outInicial) {
                self._aviso('Cargando ' + self.outInicial + '...', 'info');
                return self._llamar({route: '/koroshi/faltantes/buscar',
                                     params: {codigo: self.outInicial, out_id: false,
                                              employee_id: self._empleadoId()}});
            }
        });
    },

    on_attach_callback: function () {
        this._super.apply(this, arguments);
        this.ocupado = false;
        if (this.abrioOut) {
            // vuelve de la OUT (validada o con la flecha atras)
            this.abrioOut = false;
            if (this.desdeOperarios) {
                this.trigger_up('history_back');
                return;
            }
            this._limpiar();
            this.operario = null;
            this._aviso('', '');
        }
        this._pintar();
        this._foco();
    },

    destroy: function () {
        core.bus.off('barcode_scanned', this, this._onBarcodeScanned);
        clearTimeout(this.timerConfirmar);
        this._super.apply(this, arguments);
    },

    // ------------------------------------------------------------ estado
    _limpiar: function () {
        this.paso = 'out';         // out | ean | elegir | ubic | hecho
        this.out = null;
        this.linea = null;
        this.lineas = [];
        this.confirmarNada = false;
    },

    // ------------------------------------------------------------ lecturas
    _onBarcodeScanned: function (barcode) {
        if (!this.el || !$.contains(document, this.el)) {
            return;     // la pantalla no se ve: no es para nosotros
        }
        this._leer(barcode);
    },

    _onKeydown: function (ev) {
        if (ev.key === 'Enter' || ev.keyCode === 13) {
            ev.preventDefault();
            var $i = this.$('.o_kf_codigo');
            var c = ($i.val() || '').trim();
            $i.val('');
            if (c) { this._leer(c); }
        }
    },

    _leer: function (codigo) {
        codigo = (codigo || '').trim();
        var ahora = Date.now();
        if (!codigo || (codigo === this.ultima.codigo && ahora - this.ultima.t < REPETIDA_MS) || this.ocupado) {
            return;
        }
        this.ultima = {codigo: codigo, t: ahora};
        var peticion;
        if (this.paso === 'ubic') {
            peticion = {route: '/koroshi/faltantes/reubicar',
                        params: {move_line_id: this.linea.id, codigo: codigo, employee_id: this._empleadoId()}};
            this._aviso('Cambiando la reserva...', 'info');
        } else {
            peticion = {route: '/koroshi/faltantes/buscar',
                        params: {codigo: codigo, out_id: this.out ? this.out.id : false,
                                 employee_id: this._empleadoId()}};
        }
        return this._llamar(peticion);
    },

    _llamar: function (peticion) {
        var self = this;
        this.ocupado = true;
        return this._rpc(peticion).then(function (r) {
            self.ocupado = false;
            self._respuesta(r);
        }).guardedCatch(function () {
            self.ocupado = false;
            self._aviso('Sin conexion con Odoo o error de Odoo. No se ha cambiado nada en esta lectura.', 'mal');
            self._pitido(false);
        });
    },

    _respuesta: function (r) {
        if (!r || !r.ok) {
            this._aviso((r && r.msg) || 'Error', 'mal');
            this._pitido(false);
            return;
        }
        this._pitido(true);
        if (r.que === 'tarjeta') {
            this.operario = {id: r.operario.id, nombre: r.operario.nombre, tarjeta: true};
            this._aviso('Operario: ' + r.operario.nombre, 'info');
        } else if (r.que === 'out') {
            this._limpiar();
            this.out = r.out;
            if (r.operario && !(this.operario && this.operario.tarjeta)) {
                this.operario = {id: r.operario.id, nombre: r.operario.nombre, tarjeta: false};
            }
            this.paso = 'ean';
            this._aviso('', '');
        } else if (r.que === 'lineas') {
            this.out = r.out;
            this.lineas = r.lineas;
            this.linea = null;
            this.paso = 'elegir';
            this._aviso('Este articulo tiene varias lineas en la OUT. Elige la que no esta.', 'info');
        } else if (r.que === 'linea') {
            this.out = r.out;
            this.linea = r.linea;
            this.lineas = [];
            this.paso = 'ubic';
            this.confirmarNada = false;
            this._aviso(r.linea.motivo || '', r.linea.motivo ? 'mal' : '');
        } else if (r.que === 'hecho') {
            this.out = r.out;
            this.paso = 'hecho';
            this._aviso(r.msg + (r.nota ? ' ' + r.nota : ''), 'ok');
        }
        this._pintar();
    },

    _empleadoId: function () {
        return this.operario ? this.operario.id : false;
    },

    // ------------------------------------------------------------ botones
    _onElegirLinea: function (ev) {
        var id = parseInt($(ev.currentTarget).data('id'), 10);
        if (!id || this.ocupado) { return; }
        return this._llamar({route: '/koroshi/faltantes/buscar', params: {move_line_id: id}});
    },

    _onNada: function () {
        var self = this;
        if (this.paso !== 'ubic' || !this.linea || this.ocupado) { return; }
        if (!this.confirmarNada) {
            this.confirmarNada = true;
            this.$('.o_kf_nada').text('Pulsa otra vez para confirmar');
            clearTimeout(this.timerConfirmar);
            this.timerConfirmar = setTimeout(function () {
                self.confirmarNada = false;
                self._pintar();
            }, CONFIRMAR_MS);
            return;
        }
        clearTimeout(this.timerConfirmar);
        this.confirmarNada = false;
        this._aviso('Quitando la reserva...', 'info');
        return this._llamar({route: '/koroshi/faltantes/sin_alternativa',
                             params: {move_line_id: this.linea.id, employee_id: this._empleadoId()}});
    },

    _onVolver: function () {
        var self = this;
        if (!this.out || this.ocupado) { return; }
        var out = this.out;
        var fallo = function (msg) {
            self.ocupado = false;
            self.abrioOut = false;
            self._aviso('No se ha podido abrir ' + out.name + ': ' + msg + '. Abrela desde el menu de codigo de barras.', 'mal');
        };
        var prom;
        this.ocupado = true;
        this.abrioOut = true;
        if (out.batch_id) {
            prom = this._rpc({model: 'stock.picking.batch', method: 'start_batch_processing', args: [[out.batch_id]]})
                .then(function (accion) {
                    if (!accion) { return fallo('la agrupacion no devuelve pantalla'); }
                    return self.do_action(accion);
                });
        } else {
            prom = this._rpc({route: '/stock_barcode/scan_from_main_menu', params: {barcode: out.name}})
                .then(function (res) {
                    if (res && res.action) { return self.do_action(res.action); }
                    return fallo((res && res.warning) || 'sin respuesta');
                });
        }
        return prom.then(function () { self.ocupado = false; }).guardedCatch(function () { fallo('error de Odoo'); });
    },

    _onOtro: function () {
        // otro faltante en la misma OUT
        if (!this.out) { return this._onNuevo(); }
        var out = this.out;
        this._limpiar();
        this.out = out;
        this.paso = 'ean';
        this._aviso('', '');
        this._pintar();
        this._foco();
    },

    _onNuevo: function () {
        this._limpiar();
        this._aviso('', '');
        this._pintar();
        this._foco();
    },

    _onSalir: function () {
        if (this.desdeOperarios) {
            this.trigger_up('history_back');
        } else {
            this.do_action('stock_barcode.stock_barcode_action_main_menu');
        }
    },

    // ------------------------------------------------------------ pintar
    _aviso: function (texto, clase) {
        var $a = this.$('.o_kf_aviso');
        $a.text(texto || '');
        $a.attr('class', 'o_kf_aviso o_kf_caja' + (texto ? ' o_kf_' + clase : ''));
    },

    _pitido: function (bien) {
        try {
            var Ctx = window.AudioContext || window.webkitAudioContext;
            var ctx = new Ctx();
            var o = ctx.createOscillator();
            o.frequency.value = bien ? 880 : 220;
            o.connect(ctx.destination);
            o.start();
            setTimeout(function () { o.stop(); ctx.close(); }, bien ? 120 : 400);
        } catch (e) { /* sin sonido */ }
    },

    _foco: function () {
        var $i = this.$('.o_kf_codigo');
        if ($i.length && !('ontouchstart' in window)) { $i.focus(); }
    },

    _pintar: function () {
        if (!this.$el) { return; }
        var textos = {
            out: 'Lee la OUT',
            ean: 'Lee el artículo que no está',
            elegir: 'Elige la línea',
            ubic: 'Ve a una ubicación de la lista y lee la ubicación de donde coges la pieza',
            hecho: 'Hecho. Vuelve a la OUT',
        };
        this.$('.o_kf_paso').text(textos[this.paso] || '');
        this.$('.o_kf_quien').text(this.operario ?
            this.operario.nombre + (this.operario.tarjeta ? '' : ' (tarea)') : 'Sin operario (puedes leer tu tarjeta)');

        // OUT
        var $out = this.$('.o_kf_out').empty();
        if (this.out) {
            $out.append($('<b/>').text(this.out.name));
            if (this.out.batch_name) { $out.append(document.createTextNode(' · ' + this.out.batch_name)); }
            if (this.out.tienda) { $out.append($('<span class="o_kf_sub"/>').text(this.out.tienda)); }
        }
        $out.toggle(!!this.out);

        // linea
        var $lin = this.$('.o_kf_linea').empty();
        var l = this.linea;
        if (l && this.paso === 'ubic') {
            $lin.append($('<div class="o_kf_producto"/>').text(l.producto));
            $lin.append($('<div class="o_kf_sub"/>').text('Reservada en'));
            $lin.append($('<div class="o_kf_vieja"/>').text(l.ubicacion + ' · ' + l.cantidad + ' ud'));
        }
        $lin.toggle(!!(l && this.paso === 'ubic'));

        // alternativas
        var $alt = this.$('.o_kf_alternativas').empty();
        if (l && this.paso === 'ubic' && !l.motivo) {
            $alt.append($('<div class="o_kf_titulo"/>').text('Con stock libre (' + (l.alternativas_total || 0) + ' ubicaciones)'));
            if (!l.alternativas || !l.alternativas.length) {
                $alt.append($('<div class="o_kf_fila o_kf_nadie"/>').text('No hay stock libre en ninguna otra ubicación'));
            }
            (l.alternativas || []).forEach(function (a) {
                $alt.append($('<div class="o_kf_fila"/>')
                    .append($('<b/>').text(a.nombre))
                    .append($('<span/>').text(a.libre + ' ud')));
            });
        }

        // varias lineas
        var $ls = this.$('.o_kf_lineas').empty();
        if (this.paso === 'elegir') {
            this.lineas.forEach(function (x) {
                $ls.append($('<button type="button" class="o_kf_elegir o_kf_boton"/>').attr('data-id', x.id)
                    .text(x.ubicacion + ' · ' + x.cantidad + ' ud'));
            });
        }

        // botones
        this.$('.o_kf_nada').toggle(this.paso === 'ubic' && !!l && !l.motivo)
            .text(this.confirmarNada ? 'Pulsa otra vez para confirmar' : 'No está en ningún sitio');
        this.$('.o_kf_volver').toggle(!!this.out);
        this.$('.o_kf_otro').toggle(this.paso === 'hecho' || (this.paso === 'ubic' && !!l && !!l.motivo));
        this.$('.o_kf_codigo').attr('placeholder', {
            out: 'Escribir OUT y Enter', ean: 'Escribir EAN y Enter', elegir: 'Elige arriba',
            ubic: 'Escribir ubicación y Enter', hecho: 'Escribir OUT y Enter'}[this.paso]);
    },
});

core.action_registry.add('koroshi_faltantes_pantalla', Pantalla);
return Pantalla;
});

odoo.define('koroshi_faltantes.BotonOperarios', function (require) {
'use strict';
/* Boton "Faltante" en la pantalla de Operarios (koroshi_operarios). Al volver de la OUT, regresa alli. */
var Operarios = require('koroshi_operarios.Pantalla');

Operarios.include({
    events: _.extend({}, Operarios.prototype.events, {
        'click .o_kf_abrir_faltante': '_onFaltante',
    }),
    _onFaltante: function () {
        // v1.2: con Operarios v2 se pasa la OUT que esta haciendo (si es una OUT suelta) y el operario
        var actual = this.actual || null;
        var out = actual && actual.tipo === 'out' && this.tarea && this.tarea.tipo === 'out' ?
            actual.picking_name : false;
        return this.do_action('koroshi_faltantes.action_koroshi_faltantes_pantalla', {
            additional_context: {
                desde_operarios: true,
                faltante_out: out,
                faltante_operario: this.operario ? {id: this.operario.id, nombre: this.operario.nombre} : false,
            },
        });
    },
});
return Operarios;
});
