# KOROSHI Faltantes (v1.1, 09/11/2026)

Qué hacer en la PDA cuando una pieza de una OUT no está donde dice Odoo. Hasta ahora se ponía a 0 la ubicación desde la PDA:
el stock se iba a pérdidas sin saber quién, de qué OUT ni por qué. Del 27/10 al 09/11 se hizo 111 veces (159 uds), y el 44 % de
esos artículos tenía stock libre en otra ubicación.

Con este módulo:
- la línea de la OUT pasa a otra ubicación con stock libre;
- la pieza que no está va a **EFFEC/FALTANT**;
- queda un registro que se revisa cada día.

## En la PDA

1. Haciendo una OUT en la app de código de barras falta una pieza. Se sale con la **flecha atrás** y en la pantalla de
   **Operarios** se pulsa **Faltante**. También se abre desde *Inventario > KOROSHI Faltantes > Faltante (PDA)*.
2. Leer **la OUT** y después **el EAN** de la pieza que no está.
   - Si el artículo tiene varias líneas en la OUT, se elige la línea con un botón.
   - La OUT también se puede leer solo con el número (`23649`).
3. Sale:
   - **Reservada en:** `L46 P15 C3 · KO_140726_005 · 1 ud`;
   - **Con stock libre:** hasta 5 ubicaciones, ordenadas por el lineal más cercano al de la reservada. Para cada una se
     ve cuántas uds libres tiene (cantidad − reservado).
4. Ir a una de ellas, coger la pieza y **leer la ubicación** (la caja `KO_…` o el hueco `L44 P17 C3`). En ese momento,
   todo de golpe:
   1. la línea de la OUT pasa a esa ubicación con la reserva buena. Si se lee el hueco, se usa la caja KO de dentro con
      más stock libre;
   2. la unidad que faltaba va de la ubicación vieja a **FALTANT**;
   3. queda el registro (quién, OUT, artículo, de dónde, a dónde, hora).

   Si algo falla, no se cambia nada y sale el motivo en rojo.
5. Si no está en ningún sitio: **No está en ningún sitio** (dos pulsaciones). Se quita la reserva de esa línea, la unidad
   va a FALTANT y la OUT se valida sin esa pieza, como hasta ahora.
6. **Volver a la OUT:** la abre otra vez en la app de código de barras, ya con la ubicación nueva. Si es de una
   agrupación `Z-`, abre la agrupación.
   - Si se entró desde Operarios, al validar se vuelve a Operarios.
7. **Otro faltante en esta OUT** vuelve al paso del EAN.

La tarjeta del operario se puede leer en cualquier momento. Si no se lee, se pone el operario de la tarea abierta de esa
OUT o agrupación (koroshi_operarios).

## Ronda de revisión: ir a ver si los faltantes son reales (v1.1)

FALTANT no es un sitio de la nave: es una ubicación de Odoo donde quedan las uds que no se han encontrado. Para buscarlas
se hace una **ronda** con una INT normal, en la app de código de barras.

1. **Crear la ronda:** *Inventario > KOROSHI Faltantes > Crear ronda de revisión* (responsable de almacén).
   - Crea **una INT** (`EFFEC/INT/…`, origen `RONDA FALTANTES dd/mm hh:mm`) con todos los faltantes pendientes que
     tienen uds en FALTANT y no están ya en otra ronda.
   - Hay una línea por faltante, de **FALTANT a la ubicación donde tenía que estar**, ordenadas por lineal.
   - Para hacer la ronda solo con algunos: en *Revisión de faltantes*, seleccionarlos y después *Acción > Crear ronda con
     los seleccionados*.
2. **En la PDA:** abrir la INT como cualquier otra y, ubicación por ubicación:
   - **Está donde decía:** leer el artículo y la ubicación.
   - **Está en otra caja** (la de al lado, otra talla...): leer el artículo y **la ubicación donde está**.
   - **No está:** no leer nada de esa línea.
3. **Validar la INT.** Odoo pregunta qué hacer con lo no leído:
   - **Crear pedido pendiente:** lo no leído sigue en una INT nueva para mirarlo otro día.
   - **Sin pedido pendiente:** lo no leído se da por perdido.
4. **Cada 15 minutos** (cron *KOROSHI Faltantes: actualizar rondas*) se actualizan los faltantes solos:

   | En la INT | Faltante |
   |---|---|
   | línea leída | **Encontrado**, con la ubicación donde se leyó (el stock ya ha vuelto con la INT) |
   | validada *Sin pedido pendiente* y la línea no leída | **No encontrado**: movimiento de FALTANT a pérdidas de inventario |
   | *Crear pedido pendiente* | sigue **Pendiente**, ahora en la INT nueva (*Rondas* +1) |
   | INT **cancelada entera** | vuelve a **Pendiente** sin ronda (cancelar no es «no encontrado») |
   | línea de 2+ uds leída a medias | lo leído pasa a Encontrado y el resto queda como otro faltante |

Las rondas se ven en *Rondas de faltantes (INT)*. Mientras un faltante está en una ronda abierta no se puede marcar a mano:
se revisa en la INT.

## Revisión a mano (oficina)

*Inventario > KOROSHI Faltantes > Revisión de faltantes*: por defecto salen los pendientes. Hay filtros por día, operario,
estado, tipo y ronda, y se puede exportar a Excel (seleccionar > Exportar). Para casos sueltos fuera de ronda:

- **Encontrado:** se elige la ubicación y las uds vuelven de FALTANT a ella.
- **No encontrado:** las uds van de FALTANT a pérdidas de inventario. Es lo que antes se hacía poniendo a 0 en la PDA, pero
  ahora queda registrado.

*Puestos a 0 hoy* son los movimientos «Cantidad de producto actualizada» de hoy hacia pérdidas, agrupados por usuario.
Sirve para ver si se sigue poniendo a 0 desde la PDA en vez de usar esta pantalla.

## Qué cuenta y límites (v1)

- **Uds de la línea:** las uds de la línea de la OUT que no estaban.
- **Uds a FALTANT:** las que se han movido de verdad. Nunca más de las que Odoo tiene libres en la ubicación vieja, porque
  si no Odoo quitaría reservas a otras OUT. Si ya no quedaba nada (alguien la puso a 0), se mueve 0 y se apunta en la nota.
- Solo **líneas enteras y sin nada leído** (`qty_done = 0`). Si la línea tiene algo leído, la pantalla lo dice y no hace
  nada. El 91 % de las líneas son de 1 ud.
- La ubicación nueva tiene que tener **libre al menos lo de la línea entera**. Si no, no se cambia nada y sale cuánto hay.
  Si Odoo reserva menos de lo esperado (otra PDA ha reservado a la vez), se deshace todo y sale el aviso.
- No se sabe si otra PDA tiene abierta la misma OUT. Por eso hay que salir de la OUT antes de usar la pantalla. Con las
  zonas, cada OUT la hace una persona.

## Cómo cambia la reserva (técnico)

- **Reubicar:** `write({'location_id': nueva})` sobre la `stock.move.line` reservada. Es el write estándar de Odoo 13, el
  mismo que usa la app de código de barras al cambiar de ubicación: quita la reserva de la vieja y reserva en la nueva
  con `strict=True`, solo de stock libre.
- **No está en ningún sitio:** `unlink()` de esa `stock.move.line`. Es el estándar de Odoo: devuelve la reserva al quant y
  recalcula el estado del movimiento, como «Anular reserva» pero solo de esa línea.
- **A FALTANT y en la revisión:** `stock.move` interno con su línea ya hecha (`qty_done`) y `_action_done()`, como hace
  Odoo al ajustar cantidades.
- Todo va dentro de un *savepoint*. Si algo falla, se vuelve atrás y se limpia la caché del ORM.
- **Ronda:** `stock.picking` del tipo de transferencias internas del almacén (`int_type_id`), de FALTANT a EFFEC/Stock,
  con un `stock.move` por faltante. Se confirma con `_action_confirm(merge=False)`, para que cada faltante tenga su línea
  aunque se repitan artículo y ubicación, y después `action_assign()`. La INT solo reserva en FALTANT, que está fuera de
  Stock: no quita nada a ninguna OUT. El enlace faltante ↔ movimiento está en la tabla propia (`ronda_move_id`).
- Los automatismos de Odoo sobre albaranes no afectan a la ronda (comprobado el 09/11):
  - «Bloq» solo actúa con el usuario 68, que está desactivado;
  - los controles S4T solo actúan con OUT validadas.

## Seguridad

- **No añade campos** a `stock.picking`, `stock.move`, `stock.move.line`, `stock.picking.batch` ni `stock.picking.type`.
  Ojo: el 03/11 un campo en `stock.picking.type` tumbó la PDA.
- No toca la app de código de barras, no usa «Forzar disponibilidad» y no escribe `stock.quant` a mano.
- **EFFEC/FALTANT** es interna, dentro de la vista `EFFEC` pero **fuera de `EFFEC/Stock`**, así que ninguna OUT reserva
  allí. La pantalla se niega a funcionar si alguien la mueve dentro de Stock.
- Permisos:
  - la pantalla usa los permisos normales del usuario de almacén: puede crear faltantes, pero no borrarlos;
  - Encontrado / No encontrado solo los puede usar el responsable de almacén.
- Depende de `koroshi_operarios`, que hay que instalar antes.

## Ficheros

```
models/faltante.py              koroshi.faltante: alternativas, reubicar, sin_alternativa, revision, ronda, informe
data/cron.xml                   cron cada 15 min: actualizar faltantes desde las INT de ronda
wizard/encontrado.py            asistente Encontrado (elegir ubicacion)
controllers/main.py             /koroshi/faltantes/buscar, /reubicar, /sin_alternativa (json)
data/ubicacion.xml              EFFEC/FALTANT (noupdate)
views/assets.xml                css y js en web.assets_backend
static/src/js/faltantes_pantalla.js  accion de cliente koroshi_faltantes_pantalla + boton en Operarios
static/src/xml/faltantes.xml    plantilla de la pantalla + t-extend de la pantalla de Operarios
static/src/css/faltantes.css    estilos (dentro de .o_koroshi_faltantes)
views/faltante_views.xml        lista, ficha, pivot, filtros, acciones
views/wizard_views.xml          formulario del asistente
views/menu.xml                  Inventario > KOROSHI Faltantes
security/ir.model.access.csv    permisos
```
