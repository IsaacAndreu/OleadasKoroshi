# -*- coding: utf-8 -*-
# =============================================================================
# KOROSHI Monitor zonas - datos para la pantalla (solo lee, no cambia nada).
#
# /koroshi_monitor/datos (json, usuario con sesion): para la agrupacion elegida
# (prefijo 'Z-2210-', por defecto la ultima Z-...) devuelve una fila por OUT:
#   zona, caja de tienda, OUT, tienda, pedido, uds (movimientos no cancelados),
#   huecos (ubicaciones distintas), lineales (Lmin-Lmax o MU-xx), uds leidas,
#   estado (hecha = validada, curso = algo leido, pend = nada leido),
#   primera lectura y ultima lectura / hora de validacion (hora del usuario).
# Mismos calculos que las paginas estado-OUT-agrupaciones-Z-*.html de bin/versiones.
# =============================================================================
import re

from odoo import fields, http
from odoo.http import request

COMPANY_ID = 8          # EFFECTIVE LOGISTICS, S.L.
N_PREFIJOS = 15         # agrupaciones que salen en el desplegable

RE_LINEAL = re.compile(r' L(\d+) ')
RE_MU = re.compile(r'^(MU-\d+)')


class KoroshiMonitor(http.Controller):

    def _prefijos(self, env):
        lotes = env['stock.picking.batch'].sudo().search([('name', '=like', 'Z-%')], order='id desc', limit=300)
        vistos = []
        for lote in lotes:
            prefijo = lote.name.rsplit('-', 1)[0] + '-'
            if prefijo not in vistos:
                vistos.append(prefijo)
            if len(vistos) >= N_PREFIJOS:
                break
        return vistos

    def _hora(self, dt):
        if not dt:
            return ''
        local = fields.Datetime.context_timestamp(request.env.user, dt)
        return '%d:%02d' % (local.hour, local.minute)

    @http.route('/koroshi_monitor/datos', type='json', auth='user')
    def datos(self, prefijo=None, **kw):
        env = request.env(context=dict(request.env.context, allowed_company_ids=[COMPANY_ID]))
        prefijos = self._prefijos(env)
        if not prefijo or prefijo not in prefijos:
            prefijo = prefijos and prefijos[0] or ''
        res = {'prefijos': prefijos, 'prefijo': prefijo, 'D': [], 'pedidos': 0,
               'hora': self._hora(fields.Datetime.now())}
        if not prefijo:
            return res

        picks = env['stock.picking'].sudo().search([('batch_id.name', '=like', prefijo + '%'),
                                             ('company_id', '=', COMPANY_ID)])
        filas = {}
        for p in picks:
            nota = p.note or ''
            caja = ''
            if 'CAJA ' in nota:
                caja = nota.split('CAJA ')[1][:2].strip()
            nombre = p.partner_id.name or ''
            filas[p.id] = {
                'z': p.batch_id.name[len(prefijo):],
                'caja': caja,
                'out': p.name.replace('EFFEC/OUT/', ''),
                'tienda': nombre.split(', ')[-1],
                'pedido': p.origin or '',
                'u': 0.0, 'leido': 0.0,
                '_huecos': set(), '_l': [], '_mu': set(),
                '_a': None, '_b': None,
                '_estado': p.state, '_done': p.date_done,
            }

        movs = env['stock.move'].sudo().search_read([('picking_id', 'in', picks.ids), ('state', '!=', 'cancel')],
                                             ['picking_id', 'product_uom_qty'])
        for m in movs:
            filas[m['picking_id'][0]]['u'] += m['product_uom_qty']

        lineas = env['stock.move.line'].sudo().search_read([('picking_id', 'in', picks.ids)],
                                                    ['picking_id', 'qty_done', 'location_id', 'write_date'])
        for ml in lineas:
            f = filas[ml['picking_id'][0]]
            partes = (ml['location_id'] and ml['location_id'][1] or '').split('/')
            hueco = partes[3] if len(partes) >= 5 else partes[-1]
            f['_huecos'].add(hueco)
            lin = RE_LINEAL.search(hueco)
            if lin:
                f['_l'].append(int(lin.group(1)))
            else:
                mu = RE_MU.search(hueco)
                if mu:
                    f['_mu'].add(mu.group(1))
            f['leido'] += ml['qty_done']
            if ml['qty_done'] > 0:
                w = ml['write_date']
                if not f['_a'] or w < f['_a']:
                    f['_a'] = w
                if not f['_b'] or w > f['_b']:
                    f['_b'] = w

        D = []
        for f in filas.values():
            if f['_estado'] == 'done':
                est = 'hecha'
            elif f['leido'] > 0:
                est = 'curso'
            else:
                est = 'pend'
            lin = ''
            if f['_l']:
                lo, hi = min(f['_l']), max(f['_l'])
                lin = 'L%d' % lo if lo == hi else 'L%d-L%d' % (lo, hi)
            if f['_mu']:
                mus = sorted(f['_mu'])
                lin = (lin + ' · ' if lin else '') + mus[0] + ('…' + mus[-1] if len(mus) > 1 else '')
            fin = self._hora(f['_done']) if est == 'hecha' and f['_done'] else self._hora(f['_b'])
            D.append({
                'z': f['z'], 'caja': f['caja'], 'out': f['out'], 'tienda': f['tienda'], 'pedido': f['pedido'],
                'u': f['u'], 'huecos': len(f['_huecos']), 'lin': lin or '-', 'leido': f['leido'],
                'est': est, 'ini': self._hora(f['_a']), 'fin': fin,
            })
        D.sort(key=lambda d: d['out'])
        res['D'] = D
        res['pedidos'] = len(set([d['pedido'] for d in D]))
        return res
