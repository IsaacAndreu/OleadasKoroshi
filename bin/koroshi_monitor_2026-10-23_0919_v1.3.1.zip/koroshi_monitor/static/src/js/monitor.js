odoo.define('koroshi_monitor.monitor', function (require) {
'use strict';
// KOROSHI Monitor zonas: misma pantalla que estado-OUT-agrupaciones-Z-*.html, con datos en
// directo de /koroshi_monitor/datos. Se refresca sola cada REFRESCO ms. Solo lee.

var AbstractAction = require('web.AbstractAction');
var core = require('web.core');

var REFRESCO = 60000;
var ZS = ['D1', 'D2', 'D3', 'D4', 'D5', 'ZX'];
var COL = {D1: 'var(--km-z1)', D2: 'var(--km-z2)', D3: 'var(--km-z3)', D4: 'var(--km-z4)', D5: 'var(--km-z5)', ZX: 'var(--km-zx)'};
var EST = {hecha: 'Hecha', curso: 'Cogiéndose', pend: 'Sin empezar'};

function e(s) { return _.escape(s === undefined || s === null ? '' : String(s)); }
function n(x) { return Math.round(x).toLocaleString('es-ES'); }
function zt(z) { return '<span class="km-z" style="background:' + (COL[z] || 'var(--km-zx)') + '">' + e(z) + '</span>'; }
function hm(h) { var m = Math.round((h || 0) * 60); return Math.floor(m / 60) + ' h ' + ('0' + (m % 60)).slice(-2); }
// Personas y horas estimadas por las cajas cerradas (v1.3): sale para cualquier dia, no solo hoy
function personas(p, quien) {
    if (!p || !p.hp) { return ''; }
    return '<h2>Personas y horas</h2><p class="km-nota">Estimado por las cajas cerradas: cada cuarto de hora, cuántas ' + quien +
        ' cierran caja a la vez (huecos de hasta 30 min cuentan como trabajo). Todas las PDA usan el mismo usuario, así que no se puede saber por persona.</p>' +
        '<div class="km-grid">' + [
            [p.personas_max + (p.personas_media ? ' <small>(media ' + String(p.personas_media).replace('.', ',') + ')</small>' : ''), 'personas (máximo a la vez)'],
            [hm(p.hp), 'horas-persona'],
            [hm(p.horas_reloj), 'horas de reloj' + (p.inicio ? ' (' + e(p.inicio) + ' – ' + e(p.ultima) + ')' : '')],
            [n(p.uds_hp) + ' u/h', 'por hora-persona'],
            [n(p.uds_persona), 'uds por persona'],
            [String(p.s_ud).replace('.', ',') + ' s', 'por prenda (picking)'],
        ].map(function (k) { return '<div class="km-card km-kpi"><b>' + k[0] + '</b><span>' + k[1] + '</span></div>'; }).join('') + '</div>';
}

var Monitor = AbstractAction.extend({
    hasControlPanel: false,
    events: {
        'change .km-prefijo': '_onPrefijo',
        'click .km-refrescar': '_cargar',
        'click details > summary': '_onToggle',
    },

    init: function () {
        this._super.apply(this, arguments);
        this.prefijo = false;
        this.abiertas = {};
    },

    start: function () {
        var self = this;
        this.$el.addClass('o_koroshi_monitor');
        return this._super.apply(this, arguments).then(function () {
            self.$el.html('<main><p class="km-sub">Cargando…</p></main>');
            self._cargar();
            self.timer = setInterval(function () { self._cargar(); }, REFRESCO);
        });
    },

    destroy: function () {
        clearInterval(this.timer);
        this._super.apply(this, arguments);
    },

    _onPrefijo: function (ev) {
        this.prefijo = ev.target.value;
        this.abiertas = {};
        this._cargar();
    },

    _onToggle: function (ev) {
        // El clic en el titulo abre/cierra: se guarda como quedara para el siguiente refresco
        var det = ev.currentTarget.parentNode;
        var z = det.getAttribute('data-z');
        if (z) { this.abiertas[z] = !det.open; }
    },

    _cargar: function () {
        var self = this;
        return this._rpc({route: '/koroshi_monitor/datos', params: {prefijo: this.prefijo}}).then(function (r) {
            self.prefijo = r.prefijo;
            var scroll = self.el.scrollTop;
            self._pintar(r);
            self.el.scrollTop = scroll;
        });
    },

    _selector: function (r) {
        var et = r.etiquetas || {};
        return '<div class="km-ctl"><select class="km-prefijo">' + (r.prefijos || []).map(function (p) {
            return '<option value="' + e(p) + '"' + (p === r.prefijo ? ' selected' : '') + '>' + e(et[p] || p.replace(/-$/, '')) + '</option>';
        }).join('') + '</select><button class="btn btn-secondary km-refrescar">Refrescar</button></div>';
    },

    _pintar: function (r) {
        if (r.modo === 'tiendas') {
            return this._pintarTiendas(r);
        }
        var self = this;
        var D = r.D || [];
        var T = {u: 0, l: 0, h: 0, c: 0, p: 0};
        var Z = {};
        ZS.forEach(function (z) { Z[z] = {u: 0, l: 0, h: 0, c: 0, p: 0, uh: 0, n: 0}; });
        D.forEach(function (o) {
            if (!Z[o.z]) { Z[o.z] = {u: 0, l: 0, h: 0, c: 0, p: 0, uh: 0, n: 0}; ZS.push(o.z); }
            var z = Z[o.z], k = o.est === 'hecha' ? 'h' : o.est === 'curso' ? 'c' : 'p';
            z.n++; z.u += o.u; z.l += o.leido; z[k]++;
            if (o.est === 'hecha') { z.uh += o.u; }
            T.u += o.u; T.l += o.leido; T[k]++;
        });
        var zonas = ZS.filter(function (z) { return Z[z].n; });
        var pctT = T.u ? Math.round(100 * T.l / T.u) : 0;

        var h = '<main>';
        h += '<div class="km-cab"><h1>Cómo van las agrupaciones ' + e((r.prefijo || '').replace(/-$/, '')) + '</h1>';
        h += this._selector(r) + '</div>';
        h += '<p class="km-sub">' + r.pedidos + ' pedidos de tienda partidos por zona (' + D.length + ' OUT). Datos de Odoo a las <b>' + e(r.hora) +
            '</b>, se refresca solo cada minuto. Unidades reales (movimientos), no las columnas «Demanded/Reserved» de la lista de Odoo, que están mal en las OUT partidas.</p>';
        if (!D.length) {
            this.$el.html(h + '<p>No hay OUT en esta agrupación.</p></main>');
            return;
        }

        h += '<div class="km-grid">' + [
            [pctT + ' %', n(T.l) + ' de ' + n(T.u) + ' u leídas'],
            [T.h + ' / ' + D.length, 'OUT hechas'],
            [T.c, 'OUT cogiéndose ahora'],
            [T.p, 'OUT sin empezar'],
        ].map(function (k) { return '<div class="km-card km-kpi"><b>' + k[0] + '</b><span>' + k[1] + '</span></div>'; }).join('') + '</div>';
        h += personas(r.personas, 'zonas (una persona por zona)');

        // Totales
        h += '<h2>Totales: lo que llevan y lo que les falta</h2><div class="km-card km-scroll"><table><thead><tr><th>Zona</th><th class="r">Uds total</th><th class="r">Uds cogidas</th><th class="r">Uds que faltan</th><th class="r">%</th><th class="r">OUT total</th><th class="r">OUT hechas</th><th class="r">OUT cogiéndose</th><th class="r">OUT que faltan</th></tr></thead><tbody>';
        zonas.forEach(function (zn) {
            var z = Z[zn];
            h += '<tr><td>' + zt(zn) + '</td><td class="r">' + n(z.u) + '</td><td class="r">' + n(z.l) + '</td><td class="r"><b>' + n(z.u - z.l) + '</b></td><td class="r">' + (z.u ? Math.round(100 * z.l / z.u) : 0) + ' %</td><td class="r">' + z.n + '</td><td class="r">' + z.h + '</td><td class="r">' + z.c + '</td><td class="r"><b>' + (z.c + z.p) + '</b></td></tr>';
        });
        h += '<tr class="km-tot"><td>Total</td><td class="r">' + n(T.u) + '</td><td class="r">' + n(T.l) + '</td><td class="r">' + n(T.u - T.l) + '</td><td class="r">' + pctT + ' %</td><td class="r">' + D.length + '</td><td class="r">' + T.h + '</td><td class="r">' + T.c + '</td><td class="r">' + (T.c + T.p) + '</td></tr></tbody></table></div>';

        // Avance por zona
        h += '<h2>Avance por zona</h2><div class="km-ley"><span><i style="background:var(--km-ok)"></i>OUT hecha (validada)</span><span><i style="background:var(--km-cur)"></i>cogiéndose</span><span><i style="background:var(--km-pend)"></i>sin empezar</span></div><div class="km-card">';
        zonas.forEach(function (zn) {
            var z = Z[zn], pct = z.u ? Math.round(100 * z.l / z.u) : 0, ph = z.u ? 100 * z.uh / z.u : 0, pc = z.u ? Math.max(0, 100 * (z.l - z.uh) / z.u) : 0;
            h += '<div class="km-zona">' + zt(zn) + '<div><div class="km-fila"><span><b>' + n(z.l) + ' de ' + n(z.u) + ' u</b> (' + pct + ' %)</span><span>' + z.h + ' hechas · ' + z.c + ' cogiéndose · ' + z.p + ' sin empezar (de ' + z.n + ' OUT)</span></div>' +
                '<div class="km-barra"><i style="width:' + ph + '%;background:var(--km-ok)"></i><i style="width:' + pc + '%;background:var(--km-cur)"></i></div></div></div>';
        });
        h += '</div>';

        // Matriz tienda x zona
        var P = {}, orden = [];
        D.forEach(function (o) {
            if (!P[o.pedido]) { P[o.pedido] = {caja: o.caja, tienda: o.tienda, z: {}}; orden.push(o.pedido); }
            P[o.pedido].z[o.z] = o;
        });
        orden.sort(function (a, b) { return (parseInt(P[a].caja, 10) || 0) - (parseInt(P[b].caja, 10) || 0); });
        h += '<h2>Cada tienda en cada zona</h2><p class="km-nota">Cada casilla es una OUT: número de OUT y unidades leídas / total. Vacío = la tienda no tiene nada en esa zona.</p>';
        h += '<div class="km-card km-scroll"><table><thead><tr><th>Caja</th><th>Tienda</th><th>Pedido</th>' + zonas.map(function (z) { return '<th>' + zt(z) + '</th>'; }).join('') + '<th class="r">Leído</th></tr></thead><tbody>';
        orden.forEach(function (k) {
            var p = P[k], u = 0, l = 0;
            h += '<tr><td><b>' + e(p.caja) + '</b></td><td>' + e(p.tienda) + '</td><td class="m">' + e(k) + '</td>';
            zonas.forEach(function (z) {
                var o = p.z[z];
                if (!o) { h += '<td></td>'; return; }
                u += o.u; l += o.leido;
                h += '<td><span class="km-cel km-' + o.est + '" title="' + EST[o.est] + '">' + e(o.out) + '<br>' + n(o.leido) + '/' + n(o.u) + '</span></td>';
            });
            h += '<td class="r">' + n(l) + '/' + n(u) + '</td></tr>';
        });
        h += '</tbody></table></div>';

        // Listas por zona
        h += '<h2>OUT por zona</h2>';
        var rank = {curso: 0, pend: 1, hecha: 2};
        zonas.forEach(function (zn) {
            var L = D.filter(function (o) { return o.z === zn; });
            L.sort(function (a, b) { return rank[a.est] - rank[b.est] || (parseInt(a.caja, 10) || 0) - (parseInt(b.caja, 10) || 0); });
            var z = Z[zn];
            var abierta = zn in self.abiertas ? self.abiertas[zn] : (z.c || z.p);
            h += '<div class="km-card"><details data-z="' + e(zn) + '"' + (abierta ? ' open' : '') + '><summary>' + zt(zn) + ' ' + e(r.prefijo + zn) + ' · ' + n(z.l) + '/' + n(z.u) + ' u · ' + z.h + ' hechas, ' + z.c + ' cogiéndose, ' + z.p + ' sin empezar</summary>';
            h += '<div class="km-scroll"><table><thead><tr><th>Estado</th><th>Caja</th><th>OUT</th><th>Tienda</th><th>Pedido</th><th>Lineales</th><th class="r">Huecos</th><th>Leído</th><th>Empieza</th><th>Última / validada</th></tr></thead><tbody>';
            L.forEach(function (o) {
                var pct = o.u ? 100 * o.leido / o.u : 0, c = o.est === 'hecha' ? 'var(--km-ok)' : 'var(--km-cur)';
                h += '<tr><td><span class="km-cel km-' + o.est + '">' + EST[o.est] + '</span></td><td><b>' + e(o.caja) + '</b></td><td class="m">' + e(o.out) + '</td><td>' + e(o.tienda) + '</td><td class="m">' + e(o.pedido) + '</td><td>' + e(o.lin) + '</td><td class="r">' + o.huecos + '</td>' +
                    '<td><span class="km-mini"><i style="width:' + pct + '%;background:' + c + '"></i></span>' + n(o.leido) + '/' + n(o.u) + '</td><td>' + (o.est === 'hecha' ? '' : e(o.ini)) + '</td><td>' + e(o.fin) + '</td></tr>';
            });
            h += '</tbody></table></div></details></div>';
        });
        h += '</main>';
        this.$el.html(h);
    },
});

// Modo tiendas (v1.1): una OUT por pedido, sin zonas. Ritmo del equipo, hora prevista de fin,
// uds por hora y cada OUT con lo que ha tardado.
Monitor.include({
    _pintarTiendas: function (r) {
        var D = r.D || [];
        var eq = r.equipo || {};
        var T = {u: 0, l: 0, h: 0, c: 0, p: 0, uh: 0};
        D.forEach(function (o) {
            T.u += o.u; T.l += o.leido;
            T[o.est === 'hecha' ? 'h' : o.est === 'curso' ? 'c' : 'p']++;
        });
        var pct = T.u ? Math.round(100 * T.l / T.u) : 0;
        var paradas = D.filter(function (o) { return o.parada; });
        var et = r.etiquetas || {};
        var h = '<main>';
        h += '<div class="km-cab"><h1>Cómo van los pedidos de tienda · ' + e((et[r.prefijo] || '').replace('Tiendas ', '')) + '</h1>' + this._selector(r) + '</div>';
        h += '<p class="km-sub">' + r.pedidos + ' pedidos de tienda (' + D.length + ' OUT), una OUT por pedido. Datos de Odoo a las <b>' + e(r.hora) +
            '</b>, se refresca solo cada minuto. El ritmo es del equipo entero (todas las PDA usan el mismo usuario).</p>';
        if (!D.length) {
            this.$el.html(h + '<p>No hay OUT de tiendas ese día.</p></main>');
            return;
        }
        h += '<div class="km-grid">' + [
            [pct + ' %', n(T.l) + ' de ' + n(T.u) + ' u leídas'],
            [n(eq.uh || 0) + ' u/h', 'ritmo del equipo' + (eq.inicio ? ' (desde las ' + e(eq.inicio) + ')' : '')],
            [eq.fin_previsto ? e(eq.fin_previsto) : (T.u && T.l >= T.u ? 'hecho' : '–'), eq.fin_previsto ? 'acaba previsto a este ritmo' : (eq.ultima ? 'última lectura ' + e(eq.ultima) : 'hora prevista de fin')],
            [T.h + ' / ' + D.length, 'OUT hechas · ' + T.c + ' cogiéndose · ' + T.p + ' sin empezar'],
            [eq.activas || 0, 'personas cogiendo ahora (OUT con caja cerrada en los últimos ' + (eq.parada_min || 20) + ' min)' +
                (eq.activas && eq.uh ? ' · ~' + n(eq.uh / eq.activas) + ' u/h por persona' : '')],
            [n(eq.cajas || 0), 'cajas cerradas' + (eq.cajas ? ' · ' + (T.l / eq.cajas).toFixed(1).replace('.', ',') + ' u por caja' : '')],
        ].map(function (k) { return '<div class="km-card km-kpi"><b>' + k[0] + '</b><span>' + k[1] + '</span></div>'; }).join('') + '</div>';
        if (paradas.length) {
            h += '<div class="km-card km-aviso"><b>' + paradas.length + ' OUT cogiéndose sin cerrar caja hace más de ' + (eq.parada_min || 20) + ' min:</b> ' +
                paradas.map(function (o) { return e(o.out) + ' ' + e(o.tienda) + ' (' + o.hace + ' min)'; }).join(' · ') +
                '. Puede que esté parada, a medias en una PDA o esperando validar.</div>';
        }
        h += personas(r.personas, 'OUT');

        // Uds leidas por hora
        var ph = r.por_hora || [];
        var max = 1;
        ph.forEach(function (x) { if (x[1] > max) { max = x[1]; } });
        h += '<h2>Unidades leídas por hora</h2><div class="km-card">';
        if (!ph.length) {
            h += '<p class="km-nota">Todavía no hay lecturas.</p>';
        }
        ph.forEach(function (x) {
            h += '<div class="km-hora"><span>' + (x[0] < 10 ? '0' : '') + x[0] + 'h</span><span class="km-barra"><i style="width:' + (100 * x[1] / max) +
                '%;background:var(--km-cur)"></i></span><b>' + n(x[1]) + '</b></div>';
        });
        h += '</div>';

        // Lista de OUT
        h += '<h2>OUT de tienda</h2><p class="km-nota">Odoo solo guarda la hora de cada caja cerrada (matrícula CJ): «1ª caja» y «Última caja / validada» son esas horas. «Min» = lo que ha tardado la OUT, estimado a partir de sus cajas (hace falta 2 o más).</p>';
        h += '<div class="km-card km-scroll"><table><thead><tr><th>Estado</th><th>Tienda</th><th>Pedido</th><th>OUT</th><th>Leído</th><th class="r">Cajas</th><th class="r">Huecos</th><th>Lineales</th><th>1ª caja</th><th>Última caja / validada</th><th class="r">Hace</th><th class="r">Min</th><th class="r">u/h</th></tr></thead><tbody>';
        D.forEach(function (o) {
            var p = o.u ? 100 * o.leido / o.u : 0, c = o.est === 'hecha' ? 'var(--km-ok)' : 'var(--km-cur)';
            h += '<tr' + (o.parada ? ' class="km-parada"' : '') + '><td><span class="km-cel km-' + o.est + '">' + EST[o.est] + '</span></td><td>' + e(o.tienda) + '</td><td class="m">' + e(o.pedido) + '</td><td class="m">' + e(o.out) +
                (o.lote ? '<br><small>' + e(o.lote) + '</small>' : '') + '</td>' +
                '<td><span class="km-mini"><i style="width:' + p + '%;background:' + c + '"></i></span>' + n(o.leido) + '/' + n(o.u) + '</td><td class="r">' + (o.cajas || '') + '</td><td class="r">' + o.huecos + '</td><td>' + e(o.lin) +
                '</td><td>' + e(o.ini) + '</td><td>' + e(o.fin) + '</td><td class="r">' + (o.hace === '' ? '' : o.hace + ' min') + '</td><td class="r">' + (o.min || '') + '</td><td class="r">' + (o.uh || '') + '</td></tr>';
        });
        h += '</tbody></table></div></main>';
        this.$el.html(h);
    },
});

core.action_registry.add('koroshi_monitor', Monitor);
return Monitor;
});
