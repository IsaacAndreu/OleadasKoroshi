# -*- coding: utf-8 -*-
# =============================================================================
# KOROSHI Faltantes - una pieza de una OUT que no esta donde dice Odoo.
#
# Desde la pantalla "Faltante" de la PDA (controllers/main.py):
#   - reubicar():        la linea reservada pasa a otra ubicacion con stock libre y la unidad que falta
#                        va de la ubicacion vieja a FALTANT.
#   - sin_alternativa(): no esta en ningun sitio: se quita la reserva de esa linea y la unidad que falta
#                        va de la ubicacion vieja a FALTANT.
# En la oficina (revision diaria):
#   - action_no_encontrado(): de FALTANT a perdidas de inventario.
#   - Encontrado (wizard/encontrado.py): de FALTANT a la ubicacion que se elija.
#
# Como se cambia la reserva: se escribe location_id en la stock.move.line reservada (sin nada leido).
# Es el write estandar de Odoo 13: quita la reserva de la vieja y reserva en la nueva con strict=True,
# solo de stock libre (no quita nada a otra OUT). Nunca "Forzar disponibilidad" ni stock.quant a mano.
# Los movimientos a/desde FALTANT son stock.move con su linea hecha (qty_done) y _action_done(),
# como hace Odoo al ajustar cantidades.
# Todo dentro de un savepoint: si algo falla, no se hace nada.
# No anade campos a albaranes, movimientos, lineas, agrupaciones ni tipos de operacion.
# =============================================================================
import datetime
import re

import pytz

from odoo import api, fields, models
from odoo.exceptions import UserError
from odoo.tools import float_compare, float_is_zero

ZONA_HORARIA = 'Europe/Madrid'
MAX_ALTERNATIVAS = 5
NOMBRE_PUESTA_A_CERO = 'Cantidad de producto actualizada'   # lo que escribe Odoo al poner a 0 desde la PDA
PREFIJOS_ZONA = ('Z-',)                                      # agrupaciones que se abren enteras

RE_LINEAL = re.compile(r'\bL(\d+)\b')
RE_HUECO = re.compile(r'(L\d+\s+P\d+\s+C\d+)')


def lineal_de(ubicacion):
    """Numero de lineal (L46 -> 46) de una ubicacion o de su hueco; None si no tiene."""
    m = RE_LINEAL.search(ubicacion.complete_name or '')
    return int(m.group(1)) if m else None


def nombre_corto(ubicacion):
    """'EFFEC/Stock/NAVE2/27898 - L46 P15 C3/KO_140726_005' -> 'L46 P15 C3 · KO_140726_005'."""
    if not ubicacion:
        return ''
    completo = ubicacion.complete_name or ubicacion.name or ''
    m = RE_HUECO.search(completo)
    if m:
        hueco = m.group(1)
        return hueco if hueco in (ubicacion.name or '') else '%s · %s' % (hueco, ubicacion.name)
    return completo.split('/Stock/')[-1]


class KoroshiFaltante(models.Model):
    _name = 'koroshi.faltante'
    _description = 'KOROSHI Faltante'
    _order = 'fecha desc, id desc'

    name = fields.Char('Faltante', compute='_compute_name', store=True)
    employee_id = fields.Many2one('hr.employee', 'Operario', index=True, ondelete='set null',
                                  help='Operario de la tarjeta o de la tarea abierta de esa OUT (koroshi_operarios)')
    user_id = fields.Many2one('res.users', 'Usuario', required=True, default=lambda self: self.env.user,
                              ondelete='restrict')
    picking_id = fields.Many2one('stock.picking', 'OUT', required=True, index=True, ondelete='restrict')
    batch_id = fields.Many2one('stock.picking.batch', 'Agrupacion', related='picking_id.batch_id')
    product_id = fields.Many2one('product.product', 'Articulo', required=True, index=True, ondelete='restrict')
    cantidad = fields.Float('Uds de la linea', digits='Product Unit of Measure',
                            help='Uds de la linea de la OUT que no estaban')
    cantidad_faltant = fields.Float('Uds a FALTANT', digits='Product Unit of Measure',
                                    help='Uds que se han movido a FALTANT. Puede ser menos que la linea si en '
                                         'la ubicacion vieja ya no quedaba stock en Odoo.')
    ubicacion_vieja_id = fields.Many2one('stock.location', 'Ubicacion vieja', required=True, ondelete='restrict')
    ubicacion_nueva_id = fields.Many2one('stock.location', 'Ubicacion nueva', ondelete='restrict')
    linea_id = fields.Integer('Linea de la OUT', help='Id de la stock.move.line (solo informativo)')
    tipo = fields.Selection([
        ('reubicado', 'Reubicado'),
        ('sin_alternativa', 'Sin alternativa'),
    ], 'Tipo', required=True)
    estado = fields.Selection([
        ('pendiente', 'Pendiente'),
        ('encontrado', 'Encontrado'),
        ('no_encontrado', 'No encontrado'),
    ], 'Estado', default='pendiente', required=True, index=True)
    fecha = fields.Datetime('Fecha', required=True, default=fields.Datetime.now, index=True)
    dia = fields.Date('Dia', compute='_compute_dia', store=True, index=True)
    move_faltant_id = fields.Many2one('stock.move', 'Movimiento a FALTANT', ondelete='set null', readonly=True)
    move_revision_id = fields.Many2one('stock.move', 'Movimiento de la revision', ondelete='set null',
                                       readonly=True)
    ubicacion_revision_id = fields.Many2one('stock.location', 'Devuelto a', ondelete='set null', readonly=True)
    fecha_revision = fields.Datetime('Fecha revision', readonly=True)
    revisado_por = fields.Many2one('res.users', 'Revisado por', readonly=True, ondelete='set null')
    nota = fields.Char('Nota')
    company_id = fields.Many2one('res.company', 'Empresa', required=True,
                                 default=lambda self: self.env.company)

    # ------------------------------------------------------------------ computes
    @api.depends('picking_id', 'product_id')
    def _compute_name(self):
        for f in self:
            f.name = '%s - %s' % (f.picking_id.name or '', f.product_id.display_name or '')

    @api.depends('fecha')
    def _compute_dia(self):
        tz = pytz.timezone(ZONA_HORARIA)
        for f in self:
            f.dia = pytz.utc.localize(f.fecha).astimezone(tz).date() if f.fecha else False

    # ------------------------------------------------------------------ ubicaciones
    @api.model
    def _ubicacion_faltant(self):
        loc = self.env.ref('koroshi_faltantes.ubicacion_faltant', raise_if_not_found=False)
        if not loc:
            raise UserError('No existe la ubicacion FALTANT (koroshi_faltantes.ubicacion_faltant)')
        return loc

    @api.model
    def _raiz_stock(self, picking):
        """Stock donde se reserva (EFFEC/Stock). FALTANT debe estar fuera."""
        raiz = picking.picking_type_id.warehouse_id.lot_stock_id or picking.location_id
        faltant = self._ubicacion_faltant()
        if faltant.parent_path and raiz.parent_path and faltant.parent_path.startswith(raiz.parent_path):
            raise UserError('La ubicacion FALTANT esta dentro de %s: las OUT podrian reservar en ella. '
                            'Muevela fuera antes de usar la pantalla.' % raiz.complete_name)
        return raiz

    @api.model
    def _ubicacion_perdidas(self, product, company):
        loc = product.with_context(force_company=company.id).property_stock_inventory
        if not loc:
            raise UserError('El articulo %s no tiene ubicacion de perdidas de inventario' % product.display_name)
        return loc

    @api.model
    def _libre_por_ubicacion(self, product, dominio_ubicacion):
        """{ubicacion: uds libres (cantidad - reservado)} solo con libre > 0."""
        quants = self.env['stock.quant'].search(
            [('product_id', '=', product.id), ('quantity', '>', 0)] + dominio_ubicacion)
        libre = {}
        for q in quants:
            libre[q.location_id] = libre.get(q.location_id, 0.0) + q.quantity - q.reserved_quantity
        rounding = product.uom_id.rounding
        return {loc: qty for loc, qty in libre.items() if float_compare(qty, 0, precision_rounding=rounding) > 0}

    @api.model
    def _libre_en(self, product, ubicacion):
        """Uds libres justo en esa ubicacion (sin hijas)."""
        quants = self.env['stock.quant'].search([('product_id', '=', product.id),
                                                 ('location_id', '=', ubicacion.id)])
        return sum(q.quantity - q.reserved_quantity for q in quants)

    @api.model
    def alternativas(self, product, ubicacion_vieja, raiz):
        """Hasta MAX_ALTERNATIVAS ubicaciones con stock libre del articulo dentro de raiz, sin la vieja,
        ordenadas por el lineal mas cercano al de la vieja y despues por mas uds libres."""
        libre = self._libre_por_ubicacion(product, [('location_id', 'child_of', raiz.id),
                                                    ('location_id.usage', '=', 'internal'),
                                                    ('location_id', '!=', ubicacion_vieja.id)])
        lv = lineal_de(ubicacion_vieja)

        def orden(item):
            loc, qty = item
            lin = lineal_de(loc)
            distancia = abs(lin - lv) if (lin is not None and lv is not None) else 9999
            return (distancia, -qty, loc.complete_name or '')

        res = []
        for loc, qty in sorted(libre.items(), key=orden)[:MAX_ALTERNATIVAS]:
            res.append({'id': loc.id, 'nombre': nombre_corto(loc), 'completo': loc.complete_name,
                        'libre': qty, 'lineal': lineal_de(loc)})
        return {'lista': res, 'total': len(libre)}

    # ------------------------------------------------------------------ movimientos
    @api.model
    def _mover(self, product, qty, origen, destino, company, nombre, origin=''):
        """Movimiento interno hecho de qty uds (sin reservar: la linea ya va con qty_done)."""
        uom = product.uom_id
        move = self.env['stock.move'].create({
            'name': nombre,
            'origin': origin or nombre,
            'product_id': product.id,
            'product_uom': uom.id,
            'product_uom_qty': qty,
            'location_id': origen.id,
            'location_dest_id': destino.id,
            'company_id': company.id,
            'move_line_ids': [(0, 0, {
                'product_id': product.id,
                'product_uom_id': uom.id,
                'qty_done': qty,
                'location_id': origen.id,
                'location_dest_id': destino.id,
                'company_id': company.id,
            })],
        })
        move._action_done()
        if move.state != 'done':
            raise UserError('No se ha podido hacer el movimiento %s -> %s' % (origen.complete_name,
                                                                              destino.complete_name))
        return move

    # ------------------------------------------------------------------ comprobaciones
    @api.model
    def comprobar_linea(self, ml):
        """La linea se puede tocar: reservada, sin nada leido y la OUT sin validar. Devuelve el motivo si no."""
        if not ml or not ml.exists():
            return 'La linea ya no existe. Vuelve a leer la OUT.'
        if ml.picking_id.state in ('done', 'cancel'):
            return 'La OUT %s ya esta %s.' % (ml.picking_id.name, 'validada' if ml.picking_id.state == 'done'
                                               else 'cancelada')
        rounding = ml.product_uom_id.rounding
        if not float_is_zero(ml.qty_done, precision_rounding=rounding):
            return ('Esta linea ya tiene %s uds leidas. Termina la linea en la OUT o quita lo leido; '
                    'aqui solo se cambian lineas sin nada leido.' % ml.qty_done)
        if float_is_zero(ml.product_uom_qty, precision_rounding=rounding):
            return 'Esta linea no tiene nada reservado.'
        if ml.state not in ('assigned', 'partially_available'):
            return 'La linea no esta reservada (estado %s).' % ml.state
        return ''

    @api.model
    def _comprobar(self, ml):
        motivo = self.comprobar_linea(ml)
        if motivo:
            raise UserError(motivo)

    # ------------------------------------------------------------------ PDA
    @api.model
    def elegir_destino(self, ml, ubicacion_leida, raiz):
        """Ubicacion concreta (sin hijas con stock) donde reservar: la leida o, si es un hueco, la caja KO
        de dentro con mas stock libre. Error si no llega para la linea entera."""
        product = ml.product_id
        if not (ubicacion_leida.parent_path or '').startswith(raiz.parent_path or '-'):
            raise UserError('%s no esta dentro de %s.' % (ubicacion_leida.complete_name, raiz.complete_name))
        if ubicacion_leida.usage != 'internal':
            raise UserError('%s no es una ubicacion interna.' % ubicacion_leida.complete_name)
        if ubicacion_leida == ml.location_id:
            raise UserError('Es la misma ubicacion donde ya esta reservada. Lee la ubicacion de donde has '
                            'cogido la pieza.')
        libre = self._libre_por_ubicacion(product, [('location_id', 'child_of', ubicacion_leida.id),
                                                    ('location_id', '!=', ml.location_id.id)])
        if not libre:
            raise UserError('En %s no hay stock libre de este articulo en Odoo.' % nombre_corto(ubicacion_leida))
        destino, qty = max(libre.items(), key=lambda it: (it[1], -it[0].id))
        if float_compare(qty, ml.product_qty, precision_rounding=product.uom_id.rounding) < 0:
            raise UserError('En %s solo hay %s uds libres y la linea es de %s. No se ha cambiado nada.'
                            % (nombre_corto(destino), qty, ml.product_qty))
        return destino

    @api.model
    def _todo_o_nada(self, funcion, *args):
        """Ejecuta funcion en un savepoint y escribe en la base de datos antes de salir. Si falla, vuelve
        atras y limpia la cache del ORM para que no se escriba nada pendiente al acabar la peticion."""
        self.flush()
        try:
            with self.env.cr.savepoint():
                res = funcion(*args)
                self.flush()
                return res
        except Exception:
            self.env.clear()
            raise

    @api.model
    def reubicar(self, ml, ubicacion_leida, employee=False):
        """La linea pasa a la ubicacion leida y la unidad que falta va a FALTANT. Todo o nada."""
        return self._todo_o_nada(self._reubicar, ml, ubicacion_leida, employee)

    @api.model
    def _reubicar(self, ml, ubicacion_leida, employee=False):
        self._comprobar(ml)
        picking, product = ml.picking_id, ml.product_id
        raiz = self._raiz_stock(picking)
        faltant = self._ubicacion_faltant()
        company = picking.company_id
        vieja = ml.location_id
        qty_linea, qty_prod = ml.product_uom_qty, ml.product_qty
        destino = self.elegir_destino(ml, ubicacion_leida, raiz)

        # a) la reserva: write estandar de Odoo (quita en la vieja, reserva strict en la nueva)
        ml.write({'location_id': destino.id})
        self.flush()
        if float_compare(ml.product_uom_qty, qty_linea, precision_rounding=ml.product_uom_id.rounding) < 0:
            raise UserError('Odoo solo ha podido reservar %s de %s uds en %s. No se ha cambiado nada.'
                            % (ml.product_uom_qty, qty_linea, nombre_corto(destino)))

        # b) despues, la unidad que falta: de la vieja a FALTANT (solo lo que Odoo tiene alli libre)
        move, movido, nota = self._a_faltant(product, qty_prod, vieja, faltant, company, picking)

        # c) el registro
        return self.create({
            'employee_id': employee.id if employee else False,
            'picking_id': picking.id,
            'product_id': product.id,
            'cantidad': qty_linea,
            'cantidad_faltant': movido,
            'ubicacion_vieja_id': vieja.id,
            'ubicacion_nueva_id': destino.id,
            'linea_id': ml.id,
            'tipo': 'reubicado',
            'move_faltant_id': move.id if move else False,
            'nota': nota,
            'company_id': company.id,
        })

    @api.model
    def sin_alternativa(self, ml, employee=False):
        """No esta en ningun sitio: se quita la reserva de esa linea (como "Anular reserva" pero solo de
        ella) y la unidad que falta va a FALTANT. La OUT se valida sin esa pieza, como ahora."""
        return self._todo_o_nada(self._sin_alternativa, ml, employee)

    @api.model
    def _sin_alternativa(self, ml, employee=False):
        self._comprobar(ml)
        picking, product = ml.picking_id, ml.product_id
        self._raiz_stock(picking)
        faltant = self._ubicacion_faltant()
        company = picking.company_id
        vieja = ml.location_id
        qty_linea, qty_prod, ml_id = ml.product_uom_qty, ml.product_qty, ml.id

        # a) quitar la reserva de la linea: unlink estandar (devuelve la reserva al quant y recalcula
        #    el estado del movimiento)
        ml.unlink()

        # b) la unidad que falta: de la vieja a FALTANT
        move, movido, nota = self._a_faltant(product, qty_prod, vieja, faltant, company, picking)

        return self.create({
            'employee_id': employee.id if employee else False,
            'picking_id': picking.id,
            'product_id': product.id,
            'cantidad': qty_linea,
            'cantidad_faltant': movido,
            'ubicacion_vieja_id': vieja.id,
            'linea_id': ml_id,
            'tipo': 'sin_alternativa',
            'move_faltant_id': move.id if move else False,
            'nota': nota,
            'company_id': company.id,
        })

    @api.model
    def _a_faltant(self, product, qty, vieja, faltant, company, picking):
        """Mueve a FALTANT lo que falta, pero nunca mas de lo que Odoo tiene libre en la vieja (si no,
        Odoo quitaria reservas a otras OUT). Devuelve (move, uds movidas, nota)."""
        rounding = product.uom_id.rounding
        libre = self._libre_en(product, vieja)
        mover = min(qty, libre)
        if float_compare(mover, 0, precision_rounding=rounding) <= 0:
            return False, 0.0, 'En la ubicacion vieja ya no quedaba stock libre en Odoo: no se ha movido nada.'
        nota = ''
        if float_compare(mover, qty, precision_rounding=rounding) < 0:
            nota = 'En la ubicacion vieja solo quedaban %s uds libres en Odoo: se han movido esas.' % mover
        move = self._mover(product, mover, vieja, faltant, company,
                           'KOROSHI Faltante %s' % picking.name, picking.name)
        return move, mover, nota

    # ------------------------------------------------------------------ revision
    def _comprobar_revision(self):
        for f in self:
            if f.estado != 'pendiente':
                raise UserError('%s ya esta revisado.' % f.name)

    def action_no_encontrado(self):
        """De FALTANT a perdidas de inventario (lo que antes se hacia poniendo a 0 en la PDA)."""
        self._comprobar_revision()
        faltant = self._ubicacion_faltant()
        for f in self:
            move = False
            if not float_is_zero(f.cantidad_faltant, precision_rounding=f.product_id.uom_id.rounding):
                perdidas = self._ubicacion_perdidas(f.product_id, f.company_id)
                move = self._mover_desde_faltant(f, faltant, perdidas)
            f.write({'estado': 'no_encontrado', 'move_revision_id': move.id if move else False,
                     'ubicacion_revision_id': move.location_dest_id.id if move else False,
                     'fecha_revision': fields.Datetime.now(), 'revisado_por': self.env.user.id})
        return True

    def marcar_encontrado(self, ubicacion):
        """De FALTANT a la ubicacion elegida (asistente Encontrado)."""
        self._comprobar_revision()
        faltant = self._ubicacion_faltant()
        if ubicacion.usage != 'internal':
            raise UserError('Elige una ubicacion interna.')
        if ubicacion == faltant:
            raise UserError('Elige una ubicacion distinta de FALTANT.')
        for f in self:
            move = False
            if not float_is_zero(f.cantidad_faltant, precision_rounding=f.product_id.uom_id.rounding):
                move = self._mover_desde_faltant(f, faltant, ubicacion)
            f.write({'estado': 'encontrado', 'move_revision_id': move.id if move else False,
                     'ubicacion_revision_id': ubicacion.id,
                     'fecha_revision': fields.Datetime.now(), 'revisado_por': self.env.user.id})
        return True

    def _mover_desde_faltant(self, f, faltant, destino):
        libre = self._libre_en(f.product_id, faltant)
        if float_compare(libre, f.cantidad_faltant, precision_rounding=f.product_id.uom_id.rounding) < 0:
            raise UserError('En FALTANT solo hay %s uds de %s y este faltante es de %s. Revisa FALTANT.'
                            % (libre, f.product_id.display_name, f.cantidad_faltant))
        return self._mover(f.product_id, f.cantidad_faltant, faltant, destino, f.company_id,
                           'KOROSHI Revision faltante %s' % f.picking_id.name, f.picking_id.name)

    def action_encontrado(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Encontrado',
            'res_model': 'koroshi.faltante.encontrado',
            'view_mode': 'form',
            'target': 'new',
            'context': {'active_model': self._name, 'active_ids': self.ids,
                        'default_ubicacion_id': self[:1].ubicacion_vieja_id.id},
        }

    # ------------------------------------------------------------------ informe
    @api.model
    def action_puestos_a_cero(self):
        """Movimientos de hoy hechos poniendo cantidades a 0 (o cambiandolas) en la PDA, sin pasar por
        la pantalla Faltante. Agrupados por usuario."""
        tz = pytz.timezone(ZONA_HORARIA)
        hoy = datetime.datetime.now(tz).replace(hour=0, minute=0, second=0, microsecond=0)
        desde = fields.Datetime.to_string(hoy.astimezone(pytz.utc).replace(tzinfo=None))
        return {
            'type': 'ir.actions.act_window',
            'name': 'Puestos a 0 hoy',
            'res_model': 'stock.move',
            'view_mode': 'tree,form',
            'domain': [('name', '=', NOMBRE_PUESTA_A_CERO), ('state', '=', 'done'), ('date', '>=', desde),
                       ('location_dest_id.usage', '=', 'inventory')],
            'context': {'group_by': ['create_uid'], 'create': False},
        }
