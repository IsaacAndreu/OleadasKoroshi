odoo.define('koroshi_operarios.Pantalla', function (require) {
'use strict';
/* KOROSHI Operarios v1.1 - pantalla de lecturas dentro de Odoo (accion de cliente).
 *
 * - Es la accion inicial del usuario de la PDA: sale al entrar.
 * - Tarjeta -> operario elegido VENTANA segundos. OUT -> empieza la tarea y abre la OUT en la app de
 *   codigo de barras (la misma llamada que el menu de codigo de barras). Si la OUT es de una agrupacion
 *   de zonas (Z-...), abre la agrupacion en "procesar agrupacion" (boton start_batch_processing).
 * - Al validar, la app de codigo de barras vuelve atras (history_back) y se ve otra vez esta pantalla:
 *   on_attach_callback la deja lista para la siguiente tarjeta.
 * - Las lecturas llegan por el bus 'barcode_scanned' (como el menu de codigo de barras) o escribiendo
 *   en el campo y pulsando Enter.
 * No cambia la app de codigo de barras.
 */
var AbstractAction = require('web.AbstractAction');
var core = require('web.core');

var VENTANA = 90;          // segundos que vale la tarjeta
var REPETIDA_MS = 700;     // la misma lectura dos veces seguidas (bus + campo) cuenta una

var Pantalla = AbstractAction.extend({
    contentTemplate: 'koroshi_operarios.Pantalla',
    events: {
        'keydown .o_ko_codigo': '_onKeydown',
        'click .o_ko_dejar': '_onDejar',
        'click .o_ko_menu': '_onMenu',
    },

    init: function () {
        this._super.apply(this, arguments);
        this.operario = null;      // {id, nombre, hasta}
        this.ocupado = false;
        this.ultima = {codigo: '', t: 0};
    },

    start: function () {
        var self = this;
        core.bus.on('barcode_scanned', this, this._onBarcodeScanned);
        return this._super.apply(this, arguments).then(function () {
            self._olvidarOperario();
            self._pintarAbiertas();
            self.timerAbiertas = setInterval(self._pintarAbiertas.bind(self), 60000);
            self.timerTarjeta = setInterval(function () {
                if (self.operario && Date.now() > self.operario.hasta) { self._olvidarOperario(); }
            }, 5000);
        });
    },

    on_attach_callback: function () {
        // se vuelve a ver (p. ej. al validar en la app de codigo de barras): lista para el siguiente
        this._super.apply(this, arguments);
        this.ocupado = false;
        this._olvidarOperario();
        this._pintarAbiertas();
    },

    destroy: function () {
        core.bus.off('barcode_scanned', this, this._onBarcodeScanned);
        clearInterval(this.timerAbiertas);
        clearInterval(this.timerTarjeta);
        this._super.apply(this, arguments);
    },

    // ------------------------------------------------------------ lecturas
    _onBarcodeScanned: function (barcode) {
        if (!this.el || !$.contains(document, this.el)) {
            return;     // la pantalla no se ve (estan en la app de codigo de barras): no es para nosotros
        }
        this._leer(barcode);
    },

    _onKeydown: function (ev) {
        if (ev.key === 'Enter' || ev.keyCode === 13) {
            ev.preventDefault();
            var $i = this.$('.o_ko_codigo');
            var c = ($i.val() || '').trim();
            $i.val('');
            if (c) { this._leer(c); }
        }
    },

    _leer: function (codigo) {
        var self = this;
        codigo = (codigo || '').trim();
        var ahora = Date.now();
        if (!codigo || (codigo === this.ultima.codigo && ahora - this.ultima.t < REPETIDA_MS) || this.ocupado) {
            return;
        }
        this.ultima = {codigo: codigo, t: ahora};
        if (this.operario && ahora > this.operario.hasta) { this._olvidarOperario(); }
        this.ocupado = true;
        return this._rpc({
            route: '/koroshi/operarios/leer',
            params: {codigo: codigo, employee_id: this.operario ? this.operario.id : false},
        }).then(function (r) {
            if (!r || !r.ok) {
                self.ocupado = false;
                self._aviso((r && r.msg) || 'Error', 'mal');
                self._pitido(false);
                return;
            }
            if (r.que === 'tarjeta') {
                self.ocupado = false;
                self.operario = {id: r.employee_id, nombre: r.operario, hasta: Date.now() + VENTANA * 1000};
                self._pintarOperario(r.abierta);
                self._aviso('', '');
                self._pitido(true);
                return;
            }
            if (r.que === 'empezada') {
                self._aviso((r.msg ? r.msg.trim() + ' · ' : '') + 'Empezado ' + r.tarea.ref + ' a las ' +
                            r.tarea.inicio + ' · abriendo...', 'ok');
                self._pitido(true);
                return self._abrir(r.tarea, codigo);
            }
            self.ocupado = false;
        }).guardedCatch(function () {
            self.ocupado = false;
            self._aviso('Sin conexion con Odoo', 'mal');
            self._pitido(false);
        });
    },

    _abrir: function (tarea, codigo) {
        // abre la OUT o la agrupacion en la app de codigo de barras, como si se leyera alli
        var self = this;
        var fallo = function (msg) {
            self.ocupado = false;
            self._olvidarOperario();
            self._pintarAbiertas();
            self._aviso('Empezado ' + tarea.ref + ', pero no se ha podido abrir: ' + msg +
                        '. Abrelo desde el menu de codigo de barras.', 'mal');
        };
        var prom;
        if (tarea.tipo === 'agrupacion' && tarea.batch_id) {
            prom = this._rpc({model: 'stock.picking.batch', method: 'start_batch_processing', args: [[tarea.batch_id]]})
                .then(function (accion) {
                    if (!accion) { return fallo('la agrupacion no devuelve pantalla'); }
                    return self.do_action(accion);
                });
        } else {
            prom = this._rpc({route: '/stock_barcode/scan_from_main_menu', params: {barcode: tarea.picking_name || codigo}})
                .then(function (res) {
                    if (res && res.action) { return self.do_action(res.action); }
                    return fallo((res && res.warning) || 'sin respuesta');
                });
        }
        return prom.then(function () { self.ocupado = false; }).guardedCatch(function () { fallo('error de Odoo'); });
    },

    _onDejar: function () {
        var self = this;
        if (!this.operario || this.ocupado) { return; }
        var nombre = this.operario.nombre;
        this.ocupado = true;
        return this._rpc({route: '/koroshi/operarios/dejar', params: {employee_id: this.operario.id}}).then(function (r) {
            self.ocupado = false;
            if (!r || !r.ok) {
                self._aviso((r && r.msg) || 'Error', 'mal');
                self._pitido(false);
                return;
            }
            self._aviso(nombre + ' deja ' + r.tarea.ref + ' (' + Math.round(r.uds) + ' uds en ' + r.minutos + ' min)', 'info');
            self._pitido(true);
            self._olvidarOperario();
            self._pintarAbiertas();
        }).guardedCatch(function () {
            self.ocupado = false;
            self._aviso('Sin conexion con Odoo', 'mal');
        });
    },

    _onMenu: function () {
        this.do_action('stock_barcode.stock_barcode_action_main_menu');
    },

    // ------------------------------------------------------------ pintar
    _aviso: function (texto, clase) {
        var $a = this.$('.o_ko_aviso');
        $a.text(texto || '');
        $a.attr('class', 'o_ko_aviso o_ko_caja' + (texto ? ' o_ko_' + clase : ''));
    },

    _pitido: function (bien) {
        try {
            var Ctx = window.AudioContext || window.webkitAudioContext;
            var ctx = new Ctx();
            var o = ctx.createOscillator();
            o.frequency.value = bien ? 880 : 220;
            o.connect(ctx.destination);
            o.start();
            setTimeout(function () { o.stop(); ctx.close(); }, bien ? 120 : 400);
        } catch (e) { /* sin sonido */ }
    },

    _pintarOperario: function (abierta) {
        var $q = this.$('.o_ko_quien');
        if (!this.operario) {
            $q.attr('class', 'o_ko_quien o_ko_caja o_ko_vacio').text('Lee tu tarjeta');
            this.$('.o_ko_dejar').prop('disabled', true);
            return;
        }
        $q.attr('class', 'o_ko_quien o_ko_caja').text(this.operario.nombre);
        $('<span class="o_ko_sub"/>').text(abierta ?
            ('Tienes empezado ' + abierta.ref + ' desde las ' + abierta.inicio + '. Lee otro pedido o pulsa Dejar aquí.') :
            'Lee el pedido que vas a coger').appendTo($q);
        this.$('.o_ko_dejar').prop('disabled', !abierta);
    },

    _olvidarOperario: function () {
        this.operario = null;
        this._pintarOperario(null);
    },

    _pintarAbiertas: function () {
        var self = this;
        return this._rpc({route: '/koroshi/operarios/estado', params: {}}).then(function (r) {
            if (!r || !r.ok) { return; }
            self.$('.o_ko_reloj').text(r.ahora);
            var $c = self.$('.o_ko_abiertas').empty();
            if (!r.abiertas.length) { $c.text('Nadie'); return; }
            r.abiertas.forEach(function (t) {
                var $f = $('<div class="o_ko_fila"/>');
                var $a = $('<span/>').append($('<b/>').text(t.operario))
                    .append(document.createTextNode(' · ' + t.ref + (t.tienda ? ' · ' + t.tienda : '')));
                $f.append($a).append($('<span/>').text(t.inicio));
                $c.append($f);
            });
        });
    },
});

core.action_registry.add('koroshi_operarios_pantalla', Pantalla);
return Pantalla;
});
