# KOROSHI Caja existente (v1.2, 10/11/2026)

v1.2: el número de bultos de la OUT pequeña se corrige también cuando la validación de la PDA lo escribe después
(prueba K8 del 10/11 con la v1.1: la prenda entró bien en la CJ665009950, pero la OUT/24181 quedó con 1 bulto).

Meter prendas en una caja CJ que ya existe desde la PDA, sin crear otra caja con la misma matrícula.
Desde la v1.1 también sirve para **pasar las prendas de una OUT pequeña a la caja de otra OUT de la misma
tienda y el mismo pedido**, sin validar la OUT pequeña y sin tener que «Juntar cajas» después.

## Qué pasaba

- En la PDA, el botón de caja abre el diálogo «Nombre del Paquete» del módulo `stock_barcode_optimization`
  (Brain Station, `/opt/nath-erp/nath/custom_addons`).
- Al pulsar *Create* llama a `stock.picking.put_in_pack(package_name=...)`, que siempre crea una caja nueva
  (`super().put_in_pack()`) y le pone el nombre leído.
- Con una matrícula ya usada salía una caja duplicada. Desde el 30/10 la acción automática 20 lo bloquea.
- Las OUT pequeñas (1-3 uds, muchas de zona ZX) tenían que ir en su propia caja y luego, en expediciones,
  «Juntar cajas» desde el pedido (acción 1844).

## Qué hace

Antes de llamar al método de Brain Station, si el nombre es `CJ` + 9 números, la OUT es de EFFEC y esa matrícula
ya existe:

| La caja es...                                            | Resultado                                                        |
|----------------------------------------------------------|------------------------------------------------------------------|
| de esta OUT, sin validar                                 | las uds leídas sin caja entran en esa caja; nota en la OUT       |
| de **otra OUT sin validar** del mismo pedido y tienda    | las uds leídas **pasan a esa OUT** y entran en esa caja. Si esta OUT se queda vacía queda **cancelada** y sale de su agrupación |
| de **otra OUT ya validada** del mismo pedido y tienda    | las uds leídas van a esa caja. Al validar esta OUT entran en ella y **no cuenta como bulto** de esta OUT |
| de otra OUT de otro pedido u otra tienda                 | error «La caja CJ... es de la OUT X (tienda, pedido)»; no cambia nada |
| con stock en el almacén (no enviada)                     | error; no cambia nada                                            |
| repetida en 2 o más cajas                                | error; no cambia nada                                            |

- Pasar a otra OUT: por cada línea leída se crea un movimiento en la otra OUT (mismo producto, misma línea de
  venta) y la línea leída, con su reserva, pasa a ese movimiento y a la caja. El movimiento de la OUT pequeña se
  reduce o, si se queda a 0, se cancela. No se borra nada. Las uds sin leer se quedan en la OUT pequeña.
- Las líneas con menos uds leídas que reservadas se parten igual que hace Odoo: lo leído pasa, el resto se queda.
- Bultos: al validar una OUT, si alguna de sus cajas es de otra OUT (la que la usó primero), se descuenta de su
  «Número de bultos». Así cada caja cuenta una sola vez.
- Si la matrícula no existe, o no es una OUT de EFFEC: igual que antes (caja nueva con ese nombre).
- No añade campos a ninguna tabla ni cambia la acción automática 20, la app de código de barras ni las
  agrupaciones.
- Log: `KOROSHI CAJA EXISTENTE` en el log del servidor y notas en el chatter de las dos OUT.

## Para almacén

> **OUT pequeña de una tienda (1-3 uds)**
> 1. Coged las prendas de la OUT pequeña y leedlas en la PDA como siempre.
> 2. Botón de caja y, en vez de una matrícula nueva, leed la **matrícula de una caja de otra OUT de la misma
>    tienda** (la etiqueta pone la misma tienda y el mismo PEDIDO).
> 3. Meted las prendas en esa caja.
>    - Si esa OUT no está validada: la OUT pequeña desaparece (queda cancelada). No hay que validarla.
>    - Si esa OUT ya está validada (caja ya cerrada en expediciones): validad la OUT pequeña como siempre. No
>      cuenta como bulto aparte.
> 4. La etiqueta de la OUT pequeña no se usa: tiradla.
>
> Si sale «es de la OUT ... de otro pedido» la caja es de otra tienda o pedido: leed otra.

## Prueba (fuera de horas)

1. OUT de prueba A de EFFEC: leer 2 prendas, botón de caja, matrícula CJ nueva. Sale la caja nueva como siempre.
2. Leer 1 prenda más en A y la **misma** matrícula: queda en la misma caja, nota «Caja existente CJ...: añadidas 1 uds».
3. OUT B del **mismo pedido**, sin validar, con todas sus uds leídas: leer la matrícula de A. B queda **cancelada**,
   fuera de su agrupación, y A tiene esas uds dentro de la caja (reservadas y leídas). Validar A: bultos = 1.
4. Igual que el 3 pero con A ya validada: B valida bien, la prenda acaba en la caja de A (Inventario > Paquetes) y
   el número de bultos de B no cuenta esa caja.
5. OUT de otro pedido: leer la matrícula de A → «La caja CJ... es de la OUT ... no es del mismo pedido».
6. Comprobar en el pedido de venta que las uds entregadas cuadran.

Si algo falla: desinstalar el módulo en Aplicaciones. No deja datos propios.
