# -*- coding: utf-8 -*-
# =============================================================================
# KOROSHI Caja existente - put_in_pack(package_name) con una matricula CJ que ya existe.
#
# stock_barcode_optimization (Brain Station, custom_addons) hace:
#     put_in_pack(self, package_name=None): super().put_in_pack() (caja nueva) y despues
#     renombra la ultima caja de la OUT a package_name.
# Con una matricula ya usada eso crea una caja duplicada (la accion automatica 20 lo bloquea).
#
# Aqui, ANTES de llamar a Brain Station, si package_name es una CJ que ya existe:
#   v1.0 - la caja es de ESTA OUT: las uds leidas sin caja entran en esa caja.
#   v1.1 - la caja es de OTRA OUT del MISMO pedido y la MISMA tienda:
#          * esa OUT sin validar: las uds leidas PASAN a esa OUT y a esa caja (movimiento nuevo en la otra OUT,
#            el de esta OUT se reduce o se cancela). Si esta OUT se queda sin nada, queda CANCELADA y sale de su
#            agrupacion: no hace falta validarla ni juntar cajas despues.
#          * esa OUT ya validada: las uds leidas van a esa caja (que ya esta en Clientes). Al validar esta OUT
#            entran en la caja y esta OUT no cuenta esa caja como bulto suyo (numero de bultos).
#   Otro pedido / otra tienda / caja con stock en almacen: error y no se cambia nada.
# En cualquier otro caso se llama al super igual que antes.
# =============================================================================
import logging
import re

from odoo import _, models
from odoo.exceptions import UserError
from odoo.tools import float_compare, float_is_zero, float_round

_logger = logging.getLogger(__name__)

COMPANY_ID = 8                              # EFFECTIVE LOGISTICS, S.L.
RE_CJ = re.compile(r'^CJ\d{9}$')


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def put_in_pack(self, package_name=None):
        nombre = (package_name or '').strip().upper()
        if (nombre and len(self) == 1 and RE_CJ.match(nombre)
                and self.company_id.id == COMPANY_ID and self.picking_type_code == 'outgoing'):
            existentes = self.env['stock.quant.package'].sudo().search([('name', '=ilike', nombre)])
            existentes = existentes.filtered(lambda p: (p.name or '').strip().upper() == nombre)
            if existentes:
                return self._koroshi_anadir_a_caja(existentes, nombre)
        return super(StockPicking, self).put_in_pack(package_name=package_name)

    # ------------------------------------------------------------------ utilidades
    def _koroshi_dueno(self, paquete):
        """OUT duena de una caja: la de la primera linea (id mas bajo) que la usa como destino."""
        ml = self.env['stock.move.line'].sudo().search([('result_package_id', '=', paquete.id),
                                                        ('state', '!=', 'cancel')], order='id', limit=1)
        return ml.picking_id

    def _koroshi_mismo_pedido(self, otra):
        self.ensure_one()
        return (otra.company_id == self.company_id
                and otra.picking_type_id == self.picking_type_id
                and (otra.origin or '') == (self.origin or '') and self.origin
                and otra.partner_id == self.partner_id
                and otra.location_dest_id == self.location_dest_id)

    def _koroshi_lineas_leidas(self, nombre):
        lineas = self.move_line_ids_without_package.filtered(
            lambda ml: ml.qty_done > 0 and not ml.result_package_id and ml.state not in ('done', 'cancel'))
        if not lineas:
            raise UserError(_('No hay uds leidas sin caja en %s. Lee primero las prendas y despues la caja %s.')
                            % (self.name, nombre))
        # Reparto de lineas como stock.picking._put_in_pack de Odoo 13: lo leido queda en una linea propia,
        # lo que falta por leer se queda en otra linea sin caja
        a_meter = self.env['stock.move.line']
        for ml in lineas:
            if float_compare(ml.qty_done, ml.product_uom_qty, precision_rounding=ml.product_uom_id.rounding) >= 0:
                a_meter |= ml
            else:
                falta = float_round(ml.product_uom_qty - ml.qty_done,
                                    precision_rounding=ml.product_uom_id.rounding, rounding_method='UP')
                hecho = ml.qty_done
                nueva = ml.copy(default={'product_uom_qty': 0, 'qty_done': hecho})
                ml.write({'product_uom_qty': falta, 'qty_done': 0.0})
                nueva.write({'product_uom_qty': hecho})
                a_meter |= nueva
        return a_meter

    # ------------------------------------------------------------------ principal
    def _koroshi_anadir_a_caja(self, existentes, nombre):
        self.ensure_one()
        if len(existentes) > 1:
            raise UserError(_('La matricula %s esta repetida en %d cajas. Avisa al responsable; no se ha '
                              'cambiado nada.') % (nombre, len(existentes)))
        paquete = existentes
        if self.state in ('done', 'cancel'):
            raise UserError(_('La OUT %s ya esta validada o cancelada.') % self.name)

        usos = self.env['stock.move.line'].sudo().search([('result_package_id', '=', paquete.id),
                                                          ('state', '!=', 'cancel')])
        if not usos:
            _logger.info('KOROSHI CAJA EXISTENTE: %s rechazada en %s: sin uso', nombre, self.name)
            raise UserError(_('La caja %s ya existe y no es de ninguna OUT.\n\nNo se puede usar en %s. Lee una '
                              'matricula nueva.\nNo se ha cambiado nada.') % (nombre, self.name))
        otras = usos.mapped('picking_id') - self
        if not otras:
            # v1.0: caja de esta OUT
            if paquete.quant_ids:
                donde = ', '.join(paquete.quant_ids.mapped('location_id.display_name')[:2])
                raise UserError(_('La caja %s ya tiene stock en %s.\n\nNo se puede usar en %s. Lee una matricula '
                                  'nueva.\nNo se ha cambiado nada.') % (nombre, donde, self.name))
            return self._koroshi_meter_en_caja_propia(paquete, usos, nombre)

        # v1.1: caja de otra OUT
        dueno = self._koroshi_dueno(paquete)
        if len(otras) > 1 or dueno not in otras or not self._koroshi_mismo_pedido(dueno):
            o = dueno in otras and dueno or otras[0]
            _logger.info('KOROSHI CAJA EXISTENTE: %s rechazada en %s: es de %s (otro pedido/tienda)',
                         nombre, self.name, o.name)
            raise UserError(_('La caja %s es de la OUT %s (%s, pedido %s).\n\nNo es del mismo pedido y tienda que '
                              '%s (pedido %s). Lee una matricula de esta tienda.\nNo se ha cambiado nada.')
                            % (nombre, o.name, o.partner_id.name or '', o.origin or '-', self.name,
                               self.origin or '-'))
        if paquete.quant_ids.filtered(lambda q: q.location_id.usage != 'customer'):
            donde = ', '.join(paquete.quant_ids.mapped('location_id.display_name')[:2])
            raise UserError(_('La caja %s tiene stock en %s (no esta enviada a la tienda).\n\nNo se ha cambiado '
                              'nada.') % (nombre, donde))
        if dueno.state == 'cancel':
            raise UserError(_('La OUT %s de la caja %s esta cancelada. No se ha cambiado nada.') % (dueno.name, nombre))
        if dueno.state == 'done':
            return self._koroshi_meter_en_caja_validada(paquete, dueno, nombre)
        return self._koroshi_pasar_a_otra_out(paquete, dueno, nombre)

    def _koroshi_meter_en_caja_propia(self, paquete, usos, nombre):
        lineas = self._koroshi_lineas_leidas(nombre)
        destinos_caja = usos.mapped('location_dest_id')
        if destinos_caja and lineas.mapped('location_dest_id') != destinos_caja:
            raise UserError(_('Las prendas y la caja %s van a ubicaciones distintas. No se ha cambiado nada.') % nombre)
        nivel = self.env['stock.package_level'].search([('picking_id', '=', self.id),
                                                        ('package_id', '=', paquete.id)], limit=1)
        valores = {'result_package_id': paquete.id}
        if nivel:
            valores['package_level_id'] = nivel.id
        lineas.write(valores)
        uds = sum(lineas.mapped('qty_done'))
        self.message_post(body=_('Caja existente %s: anadidas %d uds leidas en la PDA (%d lineas). '
                                 'No se ha creado ninguna caja nueva.') % (nombre, uds, len(lineas)))
        _logger.info('KOROSHI CAJA EXISTENTE: %s -> %s, %d uds, %d lineas', self.name, nombre, uds, len(lineas))
        return True

    def _koroshi_pasar_a_otra_out(self, paquete, dueno, nombre):
        """v1.1: las uds leidas de esta OUT pasan a la OUT dueno (sin validar) y a su caja."""
        lineas = self._koroshi_lineas_leidas(nombre)
        nivel = self.env['stock.package_level'].search([('picking_id', '=', dueno.id),
                                                        ('package_id', '=', paquete.id)], limit=1)
        uds = 0.0
        productos = []
        for ml in lineas:
            mov = ml.move_id
            cant = ml.qty_done
            redondeo = mov.product_uom.rounding
            nuevo = mov.copy(default={'picking_id': dueno.id, 'product_uom_qty': cant,
                                      'move_line_ids': [], 'move_orig_ids': [], 'move_dest_ids': []})
            nuevo._action_confirm(merge=False)
            valores = {'move_id': nuevo.id, 'picking_id': dueno.id, 'result_package_id': paquete.id}
            if nivel:
                valores['package_level_id'] = nivel.id
            ml.write(valores)
            resto = mov.product_uom_qty - cant
            if float_is_zero(resto, precision_rounding=redondeo) or resto < 0:
                mov._action_cancel()
            else:
                mov.write({'product_uom_qty': resto})
                mov._recompute_state()
            nuevo._recompute_state()
            uds += cant
            productos.append(ml.product_id.default_code or ml.product_id.display_name)

        texto = ', '.join(productos[:5]) + (len(productos) > 5 and ' ...' or '')
        dueno.message_post(body=_('Caja existente %s: %d uds pasadas desde %s en la PDA (%s).')
                           % (nombre, uds, self.name, texto))
        if all(m.state == 'cancel' for m in self.move_lines):
            self.write({'batch_id': False})
            self.message_post(body=_('OUT cancelada: sus %d uds han pasado a %s, caja %s (PDA). No hay que '
                                     'validarla ni juntar cajas.') % (uds, dueno.name, nombre))
        else:
            self.message_post(body=_('%d uds pasadas a %s, caja %s (PDA). Esta OUT sigue con el resto.')
                              % (uds, dueno.name, nombre))
        _logger.info('KOROSHI CAJA EXISTENTE: %s -> %s caja %s, %d uds pasadas, %s queda %s',
                     self.name, dueno.name, nombre, uds, self.name, self.state)
        return True

    def _koroshi_meter_en_caja_validada(self, paquete, dueno, nombre):
        """v1.1: la caja es de una OUT ya validada del mismo pedido. Las uds leidas van a esa caja; al validar
        esta OUT entran en ella y esta OUT no cuenta la caja como bulto suyo (action_done)."""
        lineas = self._koroshi_lineas_leidas(nombre)
        lineas.write({'result_package_id': paquete.id})
        uds = sum(lineas.mapped('qty_done'))
        self.message_post(body=_('Caja existente %s (de %s, ya validada): %d uds leidas van a esa caja. Al validar '
                                 'esta OUT no cuenta como bulto suyo.') % (nombre, dueno.name, uds))
        _logger.info('KOROSHI CAJA EXISTENTE: %s -> caja %s de %s (validada), %d uds', self.name, nombre,
                     dueno.name, uds)
        return True

    # ------------------------------------------------------------------ bultos
    # v1.2: en la v1.1 se corregia en action_done, pero la validacion de la PDA escribe number_of_packages DESPUES
    # (K8 10/11: OUT/24181 quedo con 1 bulto). Ahora se corrige en cada escritura del campo o del estado.
    def _koroshi_corregir_bultos(self):
        if 'number_of_packages' not in self._fields or self.env.context.get('koroshi_bultos'):
            return
        for p in self:
            if p.company_id.id != COMPANY_ID or p.picking_type_code != 'outgoing' or p.state != 'done':
                continue
            cajas = p.move_line_ids.mapped('result_package_id')
            ajenas = cajas.filtered(lambda k: p._koroshi_dueno(k) != p)
            if not ajenas:
                continue
            n = len(cajas - ajenas)
            if p.number_of_packages != n:
                _logger.info('KOROSHI CAJA EXISTENTE: %s bultos %s -> %d (cajas de otra OUT: %s)', p.name,
                             p.number_of_packages, n, ', '.join(ajenas.mapped('name')))
                p.with_context(koroshi_bultos=True).write({'number_of_packages': n})

    def action_done(self):
        res = super(StockPicking, self).action_done()
        self._koroshi_corregir_bultos()
        return res

    def write(self, vals):
        res = super(StockPicking, self).write(vals)
        if not self.env.context.get('koroshi_bultos') and ('number_of_packages' in vals or 'state' in vals
                                                            or 'date_done' in vals):
            self._koroshi_corregir_bultos()
        return res
