odoo.define('koroshi_contenedores.Pantalla', function (require) {
'use strict';
/* KOROSHI Contenedores v1.1.0 - mover contenedores KO_/TT_ de un hueco a otro y limpiar huecos.
 * 0. Pasar la tarjeta de operario (se mantiene 3 min sin actividad; así queda apuntado quién lo hace).
 * Mover: escanear 1 o más contenedores (se ven prendas y reservas) y después la ubicación de destino.
 * Limpiar: escanear un hueco sin contenedores en cola: se ven sus contenedores y se archivan los que están a cero.
 * Todo dentro de .o_koroshi_contenedores. */
var AbstractAction = require('web.AbstractAction');
var core = require('web.core');
var REPETIDA_MS = 700;
var PERSONA_MS = 180000;

function _e(t) { return _.escape(t == null ? '' : String(t)); }
function _n(x) { return (Math.round((x || 0) * 100) / 100).toString().replace('.', ','); }

var Pantalla = AbstractAction.extend({
    contentTemplate: 'koroshi_contenedores.Pantalla',
    events: {
        'keydown .o_kc_codigo': '_onKeydown',
        'click .o_kc_quitar': '_onQuitar',
        'click .o_kc_vaciar': '_onVaciar',
        'click .o_kc_cambiar': '_onCambiar',
        'click .o_kc_archivar': '_onArchivar',
    },

    init: function () {
        this._super.apply(this, arguments);
        this.persona = null;
        this.conts = [];
        this.hueco = null;
        this.ocupado = false;
        this.ultima = {codigo: '', t: 0};
        this.actividadEn = Date.now();
    },

    start: function () {
        var self = this;
        core.bus.on('barcode_scanned', this, this._onBarcodeScanned);
        return this._super.apply(this, arguments).then(function () {
            self.timer = setInterval(self._vigilar.bind(self), 10000);
            self._pintar();
            self._foco();
        });
    },

    destroy: function () {
        core.bus.off('barcode_scanned', this, this._onBarcodeScanned);
        clearInterval(this.timer);
        this._super.apply(this, arguments);
    },

    _vigilar: function () {
        if (this.persona && Date.now() - this.actividadEn > PERSONA_MS) {
            this._reiniciar(true);
            this._aviso('', 'Sesión cerrada por inactividad. Pasa tu tarjeta.');
        }
    },

    _reiniciar: function (conPersona) {
        this.conts = [];
        this.hueco = null;
        if (conPersona) { this.persona = null; }
        this._pintar();
    },

    _foco: function () {
        var $c = this.$('.o_kc_codigo');
        if ($c.length && document.activeElement !== $c[0]) { $c.focus(); }
    },

    _onKeydown: function (ev) {
        if (ev.which === 13) {
            ev.preventDefault();
            var codigo = (ev.currentTarget.value || '').trim();
            ev.currentTarget.value = '';
            this._leer(codigo);
        }
    },

    _onBarcodeScanned: function (codigo) { this._leer(codigo); },

    _aviso: function (tipo, msg) {
        this.$('.o_kc_aviso').removeClass('o_kc_ok o_kc_mal o_kc_info').addClass(
            msg ? 'o_kc_' + (tipo || 'info') : '').text(msg || '');
    },

    _fin: function () { this.ocupado = false; this.actividadEn = Date.now(); },

    _sinConexion: function () { this._fin(); this._aviso('mal', 'Sin conexión con Odoo. Vuelve a probar.'); },

    _leer: function (codigo) {
        var self = this;
        codigo = (codigo || '').trim();
        if (!codigo || this.ocupado) { return; }
        var t = Date.now();
        if (codigo === this.ultima.codigo && t - this.ultima.t < REPETIDA_MS) { return; }
        this.ultima = {codigo: codigo, t: t};
        this.ocupado = true;
        return this._rpc({route: '/koroshi/contenedores/leer', params: {codigo: codigo}}).then(function (r) {
            self._fin();
            if (!r || !r.ok) {
                self._aviso('mal', (r && r.msg) || 'No se ha podido leer.');
                return;
            }
            if (r.tipo === 'persona') {
                self.persona = r.persona;
                self._aviso('ok', 'Hola, ' + r.persona.nombre + '.');
                self._pintar();
                return;
            }
            if (!self.persona) {
                self._aviso('mal', 'Primero pasa tu tarjeta de operario.');
                return;
            }
            if (r.tipo === 'contenedor') {
                self.hueco = null;
                var c = r.contenedor;
                if (!_.findWhere(self.conts, {id: c.id})) { self.conts.push(c); }
                self._aviso('', '');
                self._pintar();
                return;
            }
            if (!self.conts.length) {
                self.hueco = r.ubicacion;
                self._aviso('', '');
                self._pintar();
                return;
            }
            self.ocupado = true;
            return self._rpc({route: '/koroshi/contenedores/mover', params: {
                contenedor_ids: _.pluck(self.conts, 'id'), destino_id: r.ubicacion.id,
                employee_id: self.persona.id}}).then(function (m) {
                self._fin();
                if (!m || !m.ok) {
                    self._aviso('mal', (m && m.msg) || 'No se ha podido mover.');
                    return;
                }
                self.conts = [];
                self._pintar();
                self._aviso('ok', '✓ Movido. ' + m.msg);
            }, self._sinConexion.bind(self));
        }, self._sinConexion.bind(self));
    },

    _onArchivar: function () {
        var self = this;
        if (this.ocupado || !this.hueco || !this.persona) { return; }
        this.ocupado = true;
        return this._rpc({route: '/koroshi/contenedores/limpiar', params: {
            ubicacion_id: this.hueco.id, employee_id: this.persona.id}}).then(function (m) {
            self._fin();
            if (!m || !m.ok) {
                self._aviso('mal', (m && m.msg) || 'No se ha podido limpiar.');
                return;
            }
            self.hueco = null;
            self._pintar();
            self._aviso(m.quedan ? 'info' : 'ok', (m.quedan ? '⚠ ' : '✓ ') + m.msg);
        }, self._sinConexion.bind(self));
    },

    _onQuitar: function (ev) {
        var id = parseInt($(ev.currentTarget).data('id'), 10);
        this.conts = _.reject(this.conts, function (c) { return c.id === id; });
        this._pintar();
        this._foco();
    },

    _onVaciar: function () {
        this._reiniciar(false);
        this._aviso('', '');
        this._foco();
    },

    _onCambiar: function () {
        this._reiniciar(true);
        this._aviso('', '');
        this._foco();
    },

    _pintarHueco: function () {
        var h = this.hueco;
        if (!h) { return ''; }
        var vacios = _.where(h.contenedores, {vacio: true});
        var llenos = _.where(h.contenedores, {vacio: false});
        var html = '<div class="o_kc_card"><h3>' + _e(h.nombre) + '</h3>';
        if (!h.contenedores.length) {
            html += '<div>Sin contenedores KO_/TT_: ya está limpia.</div>';
        }
        if (h.directo_n) {
            html += '<div class="o_kc_vacio">Hay ' + _n(h.directo_uds) + ' uds en el propio hueco (fuera de contenedores).</div>';
        }
        if (llenos.length) {
            html += '<div class="o_kc_vacio">Con stock (no se archivan):</div><table>' + llenos.map(function (c) {
                return '<tr><td>' + _e(c.nombre) + '</td><td class="o_kc_n">' + c.n_lineas + ' ref. · ' +
                    _n(c.uds) + ' uds' + (c.reservadas ? ' (res. ' + _n(c.reservadas) + ')' : '') + '</td></tr>';
            }).join('') + '</table>';
        }
        if (vacios.length) {
            html += '<div>A cero (se pueden archivar):</div><table>' + vacios.map(function (c) {
                return '<tr><td>' + _e(c.nombre) + '</td><td class="o_kc_n">vacío</td></tr>';
            }).join('') + '</table><button type="button" class="o_kc_archivar">Archivar ' + vacios.length +
                ' contenedor(es) vacío(s)</button>';
        } else if (h.contenedores.length) {
            html += '<div>Ningún contenedor a cero: mueve antes lo que quede.</div>';
        }
        return html + '</div>';
    },

    _pintar: function () {
        this.$('.o_kc_persona').html(this.persona
            ? 'Persona: <b>' + _e(this.persona.nombre) + '</b> <button type="button" class="o_kc_cambiar">Cambiar</button>'
            : '');
        var paso;
        if (!this.persona) {
            paso = '0. Pasa tu tarjeta de operario';
        } else if (this.conts.length) {
            paso = 'Ahora escanea la ubicación de destino (o más contenedores).';
        } else if (this.hueco) {
            paso = 'Limpiar ubicación';
        } else {
            paso = '1. Escanea el contenedor (KO_…) para mover, o una ubicación para limpiarla';
        }
        this.$('.o_kc_paso').text(paso);
        var html = this.conts.map(function (c) {
            var filas = c.lineas.map(function (l) {
                return '<tr><td>' + _e(l.producto) + '</td><td class="o_kc_n">' + _n(l.uds) +
                    (l.reservadas ? ' (res. ' + _n(l.reservadas) + ')' : '') + '</td></tr>';
            }).join('');
            if (c.mas) { filas += '<tr><td colspan="2">… y ' + c.mas + ' referencias más</td></tr>'; }
            var cuerpo = c.n_lineas
                ? '<div>' + c.n_lineas + ' ref. · ' + _n(c.uds) + ' uds' +
                    (c.reservadas ? ' · ' + _n(c.reservadas) + ' reservadas (se conservan)' : '') +
                    '</div><table>' + filas + '</table>'
                : '<div class="o_kc_vacio">Sin prendas en el sistema</div>';
            return '<div class="o_kc_card"><button type="button" class="o_kc_quitar" data-id="' + c.id +
                '">Quitar</button><h3>' + _e(c.nombre) + '</h3><div class="o_kc_hueco">Ahora en: ' +
                _e(c.hueco) + '</div>' + cuerpo + '</div>';
        }).join('');
        this.$('.o_kc_lista').html(html);
        this.$('.o_kc_hueco_panel').html(this._pintarHueco());
    },
});

core.action_registry.add('koroshi_contenedores_pantalla', Pantalla);
return Pantalla;
});
