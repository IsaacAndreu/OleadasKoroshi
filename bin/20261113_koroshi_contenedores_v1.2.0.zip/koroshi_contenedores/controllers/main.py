# -*- coding: utf-8 -*-
# =============================================================================
# KOROSHI Contenedores - rutas de la pantalla. Con sudo: el usuario de la PDA no necesita permisos sobre
# stock.location. Solo cambian location_id del contenedor (KO_/TT_) y escriben en koroshi.contenedor.movimiento.
# =============================================================================
from odoo import http
from odoo.exceptions import UserError
from odoo.http import request

PREFIJOS = ('KO_', 'TT_')
MAX_LINEAS = 40


def _es_contenedor_nombre(nombre):
    return (nombre or '').upper()[:3] in PREFIJOS


def _msg(e):
    return e.args[0] if e.args else str(e)


class KoroshiContenedores(http.Controller):

    def _comprobar_usuario(self):
        if not request.env.user.has_group('stock.group_stock_user'):
            raise UserError('No tienes permiso para mover contenedores.')

    def _datos_contenedor(self, loc):
        Quant = request.env['stock.quant'].sudo()
        quants = Quant.search([('location_id', '=', loc.id), ('quantity', '!=', 0)])
        lineas = [{'producto': q.product_id.display_name, 'uds': q.quantity, 'reservadas': q.reserved_quantity}
                  for q in quants[:MAX_LINEAS]]
        return {
            'id': loc.id,
            'nombre': loc.name,
            'hueco': loc.location_id.complete_name or '',
            'uds': sum(quants.mapped('quantity')),
            'reservadas': sum(quants.mapped('reserved_quantity')),
            'n_lineas': len(quants),
            'lineas': lineas,
            'mas': max(0, len(quants) - MAX_LINEAS),
        }

    def _hijos_contenedor(self, hueco):
        Loc = request.env['stock.location'].sudo()
        return Loc.search([('location_id', '=', hueco.id), ('usage', '=', 'internal')]).filtered(
            lambda l: _es_contenedor_nombre(l.name))

    def _datos_hueco(self, hueco):
        """Hueco y sus contenedores KO_/TT_ con lo que tienen (para mover y para limpiar)."""
        Quant = request.env['stock.quant'].sudo()
        hijos = self._hijos_contenedor(hueco)
        quants = Quant.search([('location_id', 'in', hijos.ids + [hueco.id]), ('quantity', '!=', 0)])
        por_loc = {}
        for q in quants:
            d = por_loc.setdefault(q.location_id.id, {'uds': 0.0, 'res': 0.0, 'n': 0})
            d['uds'] += q.quantity
            d['res'] += q.reserved_quantity
            d['n'] += 1
        conts = []
        for h in hijos:
            d = por_loc.get(h.id, {'uds': 0.0, 'res': 0.0, 'n': 0})
            conts.append({'id': h.id, 'nombre': h.name, 'uds': d['uds'], 'reservadas': d['res'], 'n_lineas': d['n'],
                          'vacio': d['n'] == 0 and not d['res']})
        directo = por_loc.get(hueco.id, {'uds': 0.0, 'n': 0})
        return {'id': hueco.id, 'nombre': hueco.complete_name, 'contenedores': conts,
                'directo_uds': directo['uds'], 'directo_n': directo['n']}

    @http.route('/koroshi/contenedores/limpiar', type='json', auth='user')
    def limpiar(self, ubicacion_id=False, employee_id=False, **kw):
        """Archiva los contenedores KO_/TT_ del hueco que están a cero. Los que aún tienen stock o reservas no se tocan."""
        try:
            self._comprobar_usuario()
            emp = request.env['hr.employee'].sudo().browse(int(employee_id or 0)).exists()
            if not emp:
                raise UserError('Pasa antes tu tarjeta de operario.')
            hueco = request.env['stock.location'].sudo().browse(int(ubicacion_id or 0)).exists()
            if not hueco:
                raise UserError('Escanea la ubicación.')
            self._validar_destino(hueco)
            Quant = request.env['stock.quant'].sudo()
            Mov = request.env['koroshi.contenedor.movimiento'].sudo()
            archivados, con_stock = [], []
            for c in self._hijos_contenedor(hueco):
                quants = Quant.search([('location_id', '=', c.id), '|', ('quantity', '!=', 0),
                                       ('reserved_quantity', '!=', 0)])
                if quants:
                    con_stock.append(c.name)
                    continue
                c.write({'active': False})
                Mov.create({'accion': 'archivar', 'contenedor': c.name, 'origen_id': hueco.id,
                            'origen': hueco.complete_name, 'destino': '(archivado, vacío)',
                            'employee_id': emp.id})
                archivados.append(c.name)
            if not archivados and not con_stock:
                raise UserError('%s no tiene contenedores KO_/TT_: ya está limpia.' % hueco.complete_name)
            msg = '%s: %d contenedor(es) vacío(s) archivado(s) en %s' % (emp.name, len(archivados),
                                                                         hueco.complete_name)
            if con_stock:
                msg += '. NO se tocan por tener stock: %s' % ', '.join(con_stock)
            return {'ok': True, 'msg': msg, 'quedan': len(con_stock)}
        except UserError as e:
            return {'ok': False, 'msg': _msg(e)}

    def _validar_destino(self, destino):
        if destino.usage != 'internal':
            raise UserError('%s no es una ubicación interna.' % destino.complete_name)
        if _es_contenedor_nombre(destino.name):
            raise UserError('%s es otro contenedor: escanea la ubicación (hueco) de destino.' % destino.name)

    @http.route('/koroshi/contenedores/leer', type='json', auth='user')
    def leer(self, codigo='', **kw):
        """Un código leído: contenedor (KO_/TT_) o ubicación de destino (código de barras del hueco)."""
        try:
            self._comprobar_usuario()
            codigo = (codigo or '').strip()
            if not codigo:
                raise UserError('Código vacío.')
            Loc = request.env['stock.location'].sudo()
            if not _es_contenedor_nombre(codigo):
                emp = request.env['hr.employee'].sudo().search([('barcode', '=', codigo)], limit=1)
                if emp:
                    return {'ok': True, 'tipo': 'persona', 'persona': {'id': emp.id, 'nombre': emp.name}}
            if _es_contenedor_nombre(codigo):
                loc = Loc.search([('usage', '=', 'internal'), '|',
                                  ('name', '=ilike', codigo), ('barcode', '=ilike', codigo)])
                loc = loc.filtered(lambda l: _es_contenedor_nombre(l.name))
                if not loc:
                    raise UserError('No encuentro el contenedor %s (o está archivado).' % codigo)
                if len(loc) > 1:
                    raise UserError('Hay %d contenedores llamados %s. Avisa a IT.' % (len(loc), codigo))
                return {'ok': True, 'tipo': 'contenedor', 'contenedor': self._datos_contenedor(loc)}
            loc = Loc.search([('barcode', '=', codigo)])
            if not loc:
                raise UserError('No conozco la ubicación %s.' % codigo)
            if len(loc) > 1:
                raise UserError('Hay %d ubicaciones con el código %s. Avisa a IT.' % (len(loc), codigo))
            self._validar_destino(loc)
            return {'ok': True, 'tipo': 'ubicacion', 'ubicacion': self._datos_hueco(loc)}
        except UserError as e:
            return {'ok': False, 'msg': _msg(e)}

    @http.route('/koroshi/contenedores/mover', type='json', auth='user')
    def mover(self, contenedor_ids=None, destino_id=False, employee_id=False, **kw):
        try:
            self._comprobar_usuario()
            emp = request.env['hr.employee'].sudo().browse(int(employee_id or 0)).exists()
            if not emp:
                raise UserError('Pasa antes tu tarjeta de operario.')
            Loc = request.env['stock.location'].sudo()
            Quant = request.env['stock.quant'].sudo()
            Mov = request.env['koroshi.contenedor.movimiento'].sudo()
            destino = Loc.browse(int(destino_id or 0)).exists()
            if not destino:
                raise UserError('Escanea la ubicación de destino.')
            self._validar_destino(destino)
            conts = Loc.browse([int(i) for i in (contenedor_ids or [])]).exists()
            if not conts:
                raise UserError('Escanea antes un contenedor.')
            movidos, iguales = [], []
            for c in conts:
                if not _es_contenedor_nombre(c.name) or c.usage != 'internal' or not c.active:
                    raise UserError('%s ya no es un contenedor válido.' % c.name)
                if destino.id == c.id or (destino.parent_path or '').startswith(c.parent_path or '#'):
                    raise UserError('No se puede mover %s dentro de sí mismo.' % c.name)
                if c.location_id.id == destino.id:
                    iguales.append(c.name)
                    continue
                quants = Quant.search([('location_id', '=', c.id), ('quantity', '!=', 0)])
                origen = c.location_id
                c.write({'location_id': destino.id})
                Mov.create({
                    'contenedor': c.name, 'origen_id': origen.id, 'destino_id': destino.id,
                    'origen': origen.complete_name, 'destino': destino.complete_name,
                    'uds': sum(quants.mapped('quantity')), 'reservadas': sum(quants.mapped('reserved_quantity')),
                    'lineas': len(quants), 'employee_id': emp.id,
                })
                movidos.append(c.name)
            if not movidos:
                raise UserError('%s ya estaba en %s.' % (', '.join(iguales), destino.complete_name))
            msg = '%s: %s → %s' % (emp.name, ', '.join(movidos), destino.complete_name)
            if iguales:
                msg += ' (%s ya estaba allí)' % ', '.join(iguales)
            return {'ok': True, 'msg': msg}
        except UserError as e:
            return {'ok': False, 'msg': _msg(e)}
